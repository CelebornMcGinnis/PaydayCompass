# Finance App — Frontend

![Ledgerline](./public/ledgerline-logo-dark.png)

Real, buildable React app (Vite) that talks to the deployed backend from the
`finance-app-cdk` project. This replaces the mock-data chat-preview artifacts
with actual authenticated API calls.

## Why this is a separate downloadable project, not a chat artifact

The interactive previews built earlier in this project (Dashboard, Add Expense,
etc.) run in a sandboxed browser preview that can't install the Cognito SDK or
make authenticated calls to an external API. To actually connect to the
backend, this needed to be real, `npm install`-able project code you build and
run yourself (or deploy to the S3 bucket the CDK stack already provisions).

## Setup

```bash
npm install
cp .env.example .env.local
```

Fill in `.env.local` with the values CDK printed after deploying
(`npm run deploy:beta` in the CDK project):

| CDK output | .env.local variable |
|---|---|
| `UserPoolId` | `VITE_COGNITO_USER_POOL_ID` |
| `UserPoolClientId` | `VITE_COGNITO_CLIENT_ID` |
| (same CloudFront URL as `SiteUrl`, + `/api`) | `VITE_API_BASE_URL` |

```bash
npm run dev       # local dev server, http://localhost:5173
npm run build     # production build -> dist/
```

To deploy: upload the contents of `dist/` to the `SiteBucketName` CDK printed
(the S3 bucket CloudFront serves from). `aws s3 sync dist/ s3://<bucket-name>`.

## What's wired so far

- **Login** (`src/pages/Login.jsx`) — real Cognito SRP sign-in via
  `amazon-cognito-identity-js`, including a real MFA challenge step (TOTP
  code entry) for when Cognito Plus tier's adaptive auth challenges a
  sign-in.
- **MFA Setup** (`src/pages/MfaSetup.jsx`, route `/settings/mfa`) — full
  TOTP enrollment: generates a QR code (via `qrcode.react`) plus a manual
  entry code, verifies the first code the user's authenticator app
  produces, then sets TOTP as the account's preferred/enabled MFA method.
  Not yet linked from anywhere in the UI since Settings itself isn't wired
  up - navigate to `/settings/mfa` directly for now.
- **Dashboard** (`src/pages/Dashboard.jsx`) — real `GET /accounts`
- **Add Expense** (`src/pages/AddExpense.jsx`) — real `POST
  /accounts/{id}/transactions`, matching the split-purchase contract
- **Account Detail** (`src/pages/AccountDetail.jsx`) — real account +
  transaction fetch; trend chart and category breakdown are derived from
  that real history, not fabricated
- **Budgets** (`src/pages/Budgets.jsx`) — real budgets/projections. Per-
  category spend is now returned directly by `GET /budgets`
  (`spentAmount` field) — the earlier N+1 client-side workaround was
  removed once that was fixed server-side.
- **Payday** (`src/pages/Payday.jsx`) — real `GET /payday/upcoming` /
  `POST /payday/submit`, including editable per-occurrence overrides, the
  bank-account aggregate table, unpredicted amounts (with a real account
  picker per row), and sending fund-movement notifications to eligible
  shared recipients
- **Category Trends** (`src/pages/CategoryTrends.jsx`, route `/trends`) —
  spending by category over time across every account, with a 3M/6M/1Y/5Y
  range selector. Computed client-side from real transaction history
  (there's no dedicated backend endpoint for this yet); top 5 categories
  by spend get their own line, everything else groups into "Other"
- **External Bank Accounts** (`src/pages/ExternalBankAccounts.jsx`, route
  `/external-bank-accounts`) — real CRUD (list, add, rename, delete)
  against the deployed API
- **Manage Recurring** (`src/pages/ManageRecurring.jsx`, route
  `/recurring`) — real CRUD for recurring income/expense templates,
  including the external-bank-account dropdown. Wiring this surfaced that
  the backend's edit endpoint was still a `501 not implemented` stub - it's
  been implemented in the CDK repo (see that repo's README) as part of
  this work, not just the frontend.
- **Settings** (`src/pages/Settings.jsx`, route `/settings`) — real
  password change (`changePassword`), email change (two-step: request +
  confirm code, via `requestEmailChange`/`confirmEmailChange`), real
  toggles for budget-threshold alerts, low-balance alerts (with a
  threshold amount input), and shared-activity alerts (all backed by
  `/preferences`), per-recurring-item alert toggles, a link to MFA setup,
  and account deletion (type "DELETE" to confirm, then
  `POST /account/delete-me`).
- **Getting Setup** (`src/pages/GettingSetup.jsx`, route
  `/getting-setup`) — real first-account creation and a communication-
  preferences step, skippable at every step. **Now automatically shown to
  brand-new users**: `App.jsx`'s route guard checks the
  `custom:hasCompletedSetup` Cognito attribute and redirects there if it
  isn't `"true"` yet, and the wizard sets it (via `markSetupComplete` in
  `cognito.js`) on finish or skip so it's never shown again after that.
  This required a new custom attribute on the User Pool - see the CDK
  repo's README for an important caveat if either environment has
  already been deployed with real users in it.
- **Walkthrough** (`src/components/Walkthrough.jsx`) — a spotlight tour
  over the REAL Dashboard's real rendered elements (net worth stamp,
  account list, add-account control, nav menu), measured live via
  `getBoundingClientRect` on refs - not a fake replica of the screen like
  the original mock. Triggered by `?tour=1` on the Dashboard route
  (Getting Setup launches it automatically on finish), and replayable
  anytime from Settings → Help → "Replay app tour". A step whose target
  isn't currently on the page (e.g. the account list with zero accounts)
  is skipped rather than spotlighting nothing.
- **Dashboard navigation fix**: wiring the walkthrough surfaced that
  Dashboard's menu only had "Sign out" in it - no way to reach Budgets,
  Payday, Recurring, Trends, External Bank Accounts, or Settings from the
  main screen at all, and "Add an account" linked to `/accounts/new`,
  which has no matching route. Both fixed: the menu now links to every
  wired screen, and "Add an account" is a real inline form.
- **Planned Expenses** (`src/pages/PlannedExpenses.jsx`, route
  `/planned-expenses`) — real CRUD, server-computed suggested
  contribution per item, and a client-side normalized-monthly total
  across everything planned. **Known gap surfaced while wiring this**: the
  original design called for planned expenses to be independently
  shareable (`dataPermissions.plannedExpenses` in the Sharing table), but
  `planned-expenses-fn` has zero sharing awareness - it's strictly
  owner-only, unlike accounts/transactions/recurring which now go through
  `resolve_account_access`. Wired against what the backend actually does
  rather than build UI implying sharing works here; a real follow-up if
  that feature still matters.

## What's next

When Settings gets wired (next in the remaining-screens list), add a link
to `/settings/mfa` there so enrollment is actually discoverable instead of
requiring a direct URL visit.

## Architecture

```
src/
  lib/
    cognito.js       real Cognito auth (sign in, token refresh, sign out)
    apiClient.js      fetch wrapper - attaches the ID token, throws ApiError
    authContext.jsx   React context: are we signed in, as whom
    theme.js          the ledger/passbook design tokens, shared by every page
  pages/
    Login.jsx         wired
    Dashboard.jsx      wired
    AddExpense.jsx      wired
  App.jsx             routing + auth-gating
```

- **Sharing** (`src/pages/Sharing.jsx`, route `/sharing`) — **the first
  real UI for this feature at all.** Backend `sharing-fn` already fully
  supported creating invites with per-data-type permissions, but there
  was no `GET /sharing` (added in this pass) and no frontend screen to
  create, view, accept, or decline shares - the feature existed only as
  raw API calls nobody could reach. This screen: sends invites (account
  permission + independent per-data-type permissions, including
  recurring), shows pending invites waiting on your response, lists
  accounts you've shared out and their status, and lists accounts shared
  with you. No revoke-by-owner yet - only accept/decline by the invited
  user.
- **Recurring sharing now actually enforced**: `recurring-fn` previously
  gated everything on the flat account-level permission; it now checks
  `dataPermissions.recurring` specifically, matching the original
  independent-sharing design. Once `dataPermissions.recurring` is set on
  a share, `ManageRecurring.jsx` and `Settings.jsx` pick up those items
  automatically (no per-screen changes needed there) since they already
  iterate every account `GET /accounts` returns, which includes shared
  accounts. Fixed a real bug surfaced by this: both screens used to fetch
  every account's recurring items with `Promise.all`, which would have
  broken the ENTIRE list the moment one shared account legitimately had
  no recurring access (a 404) - now tolerant of per-account failures.
- **Scenarios** (`src/pages/Scenarios.jsx`, route `/scenarios`) — real
  throwaway preview calculations, saving named scenarios, and comparing
  up to 6 saved scenarios side by side against a shared baseline. Every
  calculation happens server-side against today's real income/budgets/
  planned expenses - nothing here is a frozen snapshot.
- **Notifications** (`src/pages/Notifications.jsx`, route
  `/notifications`) — the peer fund-movement feature: mutual-consent
  agreement management (propose, accept/decline, revoke with a
  confirmation dialog) and sending/viewing actual fund-movement alerts.
  One real backend limitation surfaced and left as-is rather than worked
  around: `GET /peer-notifications` only returns alerts where the caller
  is the RECIPIENT - a sender has no way to view a history of alerts
  they've sent, since the table's only queryable by recipient. Not
  something this screen tries to fake.
- **Terms & Privacy** (`src/pages/Legal.jsx`, route `/legal`) — static
  content, ported faithfully from the original placeholder draft
  (including the prominent "not reviewed by an attorney" disclaimer).
  Currently behind the same auth guard as every other route; ideally
  Terms should be visible before someone creates an account, not only
  after signing in - worth revisiting once there's an actual signup flow
  to link it from.

- **Sign Up** (`src/pages/SignUp.jsx`, route `/signup`, public - not
  behind `RequireAuth`) — **a real, previously-missing gap**: despite the
  Cognito pool having `selfSignUpEnabled: true` since early in this
  project, no frontend sign-up flow was ever built. The only way to get a
  user into the app was an admin manually creating one via the Cognito
  console/CLI - there was no actual self-service path, which was only
  discovered when someone tried to load the real deployed Login screen
  and found no way to create an account. Fixed: real account creation
  (`signUp`), email confirmation with the code Cognito sends
  (`confirmSignUp`), a resend option, and client-side password-policy
  validation matching the pool's actual rules (10+ chars, upper/lower/
  digit/symbol) so a new user sees what's required before submitting
  rather than getting a raw Cognito rejection. Cross-linked with Login.

**All 18 screens are now wired to the real backend** (17 app screens +
Sign Up). See the CDK repo's
`DEPLOY.md` for the beta deployment checklist.

## Real logo and favicons

`public/ledgerline-logo-{light,dark}.png` (full lockup with wordmark) and
`public/ledgerline-favicon-{light,dark}.png` (mark only) replace the
placeholder "$" glyph used everywhere during earlier development.
`index.html` wires both favicon variants via `prefers-color-scheme` media
queries (dark-mode browsers get the light-linework-on-dark version, and
vice versa), plus an `apple-touch-icon`. Since the app's UI is dark-navy
everywhere, Login/SignUp/Getting Setup/Dashboard all use the `-dark`
favicon variant (light linework, visible against the dark background) -
the `-light` variant is used for the browser favicon in light mode and
the README header image.

## Feedback-driven fixes, round 6

- **Header staying visible on scroll**: found the real cause - an earlier
  fix for the mobile "zoomed in" bug set `overflow-x: hidden` on both
  `html` and `body`, and `overflow-x` on `html` specifically (the true
  root scrolling box) is a known way to break `position: sticky` for
  descendants in some browsers. Moved it to `body`-only, which keeps the
  mobile fix without breaking every page's sticky header.
- **Add Expense from Account Detail**: added - `AddExpense.jsx` already
  supported a `?accountId=` query param, this just needed a button
  pointing at it.
- **Menu closes on outside click**: implemented in both `PageHeader` and
  Dashboard's separate menu implementation, via a ref + document
  `mousedown` listener.
- **Clickable-item hover affordance**: added transition/hover-opacity to
  header buttons as a start - not an exhaustive pass across all 18 pages.
- **Pending-share notification dot**: a small red dot on the hamburger
  icon and the "Sharing" nav item when there's a pending invite waiting
  on the user, in both `PageHeader` and Dashboard's menu.
- **Shared-account indicator**: Account Detail now shows "Shared with
  you · [permission]" when viewing an account you don't own.
- **Sharing page rewritten** for the new backend (see the CDK repo's
  README for the schema bug this surfaced and fixed): the invite form is
  now a multi-select checklist of accounts instead of one dropdown, and
  every list on the page (pending invites, sent shares, accepted shares)
  now groups rows by the other person rather than keying by
  `ownerUserId`/`invitedUserId` alone - which would have produced
  duplicate React keys and only shown one of several accounts per person
  once batch invites were possible. Added a real revoke button (owner
  side) and an info bubble explaining View vs. Edit access, confirming
  it's actually enforced server-side, not just a UI toggle with no effect.



- **PageHeader**: restored the "back to previous screen" button
  (browser-history back) alongside the "back to dashboard" one - the
  header rollout had replaced it entirely with just the dashboard
  shortcut, losing the ability to return to wherever you actually came
  from. Also bumped the logo mark's size (20px → 26px) for better
  recognizability, since the uploaded "correct" logo files turned out to
  be byte-for-byte identical (confirmed via md5sum) to what was already
  integrated - the files were never wrong, the mark was just small enough
  to read as a generic icon rather than a logo.
- **Budgets**: real delete, via a "Delete this budget" button inside the
  edit form (the whole card is a click target for editing, so a separate
  delete affordance couldn't live on the card itself without conflicting
  with that).
- **Payday**, three real fixes:
  - The "unpredicted amount" category dropdown was a hardcoded list
    unrelated to the user's actual budget categories. Now pulls real
    categories from `budgetsApi.list()`, merged with a small default set.
  - Unpredicted amounts now persist to `localStorage` (keyed per user
    email) and survive navigating away, only clearing after a real
    successful submit - previously held only in React state, gone the
    moment you left the page.
  - Expenses due within 5 days after payday now show in their own
    "Due within 5 days after" section, informational only - explicitly
    excluded from the actual submit payload and the leftover-money total,
    since including them would have posted bills before their real due
    date and misstated how much is actually left over this cycle.

## Feedback-driven fixes, round 4 — global header rollout complete

- **Global header, fully rolled out** to every page that should have one:
  `src/components/PageHeader.jsx` (logo, back-to-dashboard button, page
  title, optional subtitle, and the same nav menu as Dashboard) is now
  used on all 14 non-Dashboard pages that have a header at all. Correctly
  left alone: Login/SignUp (pre-auth, a dashboard link makes no sense),
  Getting Setup (mid-wizard, navigating away is disruptive), NotFound
  (already has its own way back), and ManageRecurring's create/edit
  *sub-view* (which intentionally goes back to the list, not the
  dashboard, since it's a nested step within the page, not a top-level
  page itself — swapping it to PageHeader was tried and reverted once
  this was noticed). `NAV_LINKS` extracted to `src/lib/navLinks.js` as
  the single source of truth Dashboard and PageHeader both use, instead
  of Dashboard's copy being the only one. AccountDetail's small icon
  badge and Payday's dynamic "due [date]" subtitle were preserved via a
  `subtitle` prop rather than silently dropped for consistency's sake.
  Cleaned up every now-unused `useNavigate`/icon import left behind by
  the swap - confirmed via a rebuild producing an identical bundle hash,
  proving the cleanup was behavior-neutral.
- **Sharing invite display**: previously showed literally nothing about
  who was sharing an account with you - not even an email. Backend now
  resolves the owner's email via the same Cognito lookup used elsewhere
  (`lookup_email_by_sub`) and returns it on every `asInvited` share;
  frontend shows it on both the pending-invite card and the "shared with
  you" list, plus which extended data types (recurring, budgets, etc.)
  were included beyond the base account access.
- **Recurring's category field** now has the same inline "+ Add a new
  category" affordance as Budgets.
- **Budgets "new category doesn't save" - root-caused, not just
  patched**: it genuinely was saving. `_list_budgets` only ever returned
  budgets already in effect, and a new budget's start date gets snapped
  forward to the user's next paycheck (often days away) - so a
  just-created budget was completely invisible until that future date
  arrived, indistinguishable from a silent failure. Fixed to show
  not-yet-started budgets immediately, clearly labeled "Starts [date]"
  instead of a spend bar with nothing to show yet.

**Not done**: dark/light mode, landing page, per-page purpose blurbs,
chart/graph placeholders, retroactive-date-entry-with-confirmation
(Budgets/Recurring/Scenarios), Scenarios UX improvements, Payday
rename+history, import/export - see prior round's notes for the full
remaining list and reasoning.



- **Found and fixed the real cause of "Loading…" showing as literal
  text** (`Loading\u2026`) - a JSX quirk, and the answer to an earlier
  open question from the big feedback round. `\u2026` is a valid escape
  sequence inside a JS string (`{loading ? "Saving\u2026" : "Save"}`
  correctly renders "Saving…"), but JSX text content written directly
  between tags (not inside `{}`) is NOT parsed for JS escapes at all - it
  renders literally. This exact mistake was present in 18 files across
  the app, not just the one reported instance (Budgets' "Add a new
  category" option) - found via a project-wide grep and fixed everywhere
  in one pass by replacing the literal escape-sequence text with the
  actual Unicode ellipsis character, which is valid and correct in both
  contexts.
- **Recurring form layout shift when toggling Expense/Income**: not a
  component-level issue - the page's total height changes between the two
  modes (different fields shown), which crosses the viewport threshold
  and toggles the browser's own page scrollbar on/off, shifting available
  content width either way. Fixed globally in `index.css` with
  `scrollbar-gutter: stable` on `html`, which always reserves the
  scrollbar's space whether or not it's actually needed - this fixes the
  Recurring form specifically and prevents the same shift on any other
  page with a similar height-changing-on-toggle pattern.



- **Mobile horizontal-overflow fix**: `index.css` had no guard against a
  single element exceeding the viewport width dragging the whole page
  into horizontal scroll (the "appears zoomed in" symptom). Added
  `overflow-x: hidden` + `max-width: 100vw` at the `html, body` level -
  the standard fix for this symptom class. Caveat: this is a safety net,
  not a guarantee every individual element is perfectly responsive: if a
  specific element still visibly clips after this, that's a real,
  separate bug worth reporting with the specific page/element.
- **Found and fixed a systemic bug, not just the one reported instance**:
  Planned Expenses' "Edit" populating stale/blank fields was a React gotcha
  - the create form and the edit form are the same mounted component
  instance (the list stays visible below the form, so clicking Edit on a
  different item just changes props on an already-mounted form), and
  `useState()`'s initial value only runs on first mount, so the fields
  never updated to match the new item. Fixed with a `key` prop that
  changes per item, forcing a real remount. Audited every other page with
  the same list-plus-form pattern: `Budgets.jsx` had the identical latent
  bug (not yet reported, but confirmed present) and got the same fix;
  `ManageRecurring.jsx` uses a different pattern (full-page swap, form and
  list never both mounted) so it isn't affected; `Sharing.jsx`'s form has
  no edit capability at all so the bug can't manifest there.
- **Budgets**: budget cards are now clickable and open a pre-filled edit
  form (previously had zero click handler at all). Category dropdown now
  has an inline "+ Add a new category" option.
- **Recurring**: the Expense/Income toggle is now red for Expense, green
  for Income (was the same accent-teal color for both).
- **Getting Setup**: now supports adding multiple accounts in one pass -
  "Save, add another" vs "Save and continue," with a running list of
  what's been added so far.

**Not done in this round** (deliberately deferred - see the chat for the
full sequencing plan): dark/light mode toggle, global header component
(logo + menu + theme toggle on every page), a landing page, per-page
"what is this page for" blurbs, replacing "Loading…" text with a real
loading indicator, trend/graph placeholders anywhere, the
retroactive-date-entry-with-confirmation-dialog feature (Budgets/
Recurring/Scenarios), Scenarios improvements, renaming Payday, import/
export, and the Account Detail / Category Trends error reports (likely
already resolved by the CORS fix from last session, pending confirmation
after a real redeploy + retest).



- **Account types restricted to checking/savings only** (Dashboard,
  Getting Setup) - "for now," per feedback; credit/investment/other still
  exist in the backend's valid-type set, just hidden from the UI.
- **Verification screen now auto-signs-in and redirects straight to the
  dashboard** after confirming the code, rather than showing a separate
  "you're all set, now go sign in" screen - a brand-new user lands
  straight in Getting Setup via the existing `hasCompletedSetup` redirect
  logic. This also resolves what to put on the old confirmation screen,
  since that screen no longer exists.
- **Getting Setup's notification toggles fixed** - they only visually
  updated after a successful backend save; a failed save (for any reason)
  left them looking unresponsive with no error shown. Now optimistic
  (toggles immediately) with a visible revert + error message if the save
  actually fails.
- **Budgets form** now has explanatory info bubbles on Category, Monthly
  amount, and Start date, each describing what that field actually
  affects elsewhere in the app (grounded in the real backend behavior,
  not generic text).
- **Custom 404 page** added as a catch-all route.
- **Walkthrough enhancement**: the Dashboard tour now actually opens the
  menu and walks through every item in it with a real description,
  instead of just pointing at the closed hamburger icon. Fixed a real
  timing bug in `Walkthrough.jsx` in the process - a step's target
  element (like a menu item) may not exist in the DOM yet if opening it
  is an async side effect of the tour itself; the component now retries
  briefly before concluding a target is genuinely absent. **Not done**:
  the broader ask for a full walkthrough on every individual page (~18
  screens) - flagged as a larger follow-up, not attempted here.
- **Not yet resolved**: "Failed to fetch" when creating an account during
  Getting Setup, and "Couldn't load your budgets"/"your upcoming payday."
  Leading theory is testing against a stale backend deployment (several
  fixes this session, including the accounts-fn/peer-notifications-fn
  Decimal bugs, may not be live) - `budgets-fn` and `payday-fn` were
  re-checked and already have the correct Decimal handling, so if these
  persist after a fresh `npm run deploy:beta`, they need their own
  diagnosis (browser Network tab detail for the exact failing request).

## The wiring pattern (for reference / future screens)

Every screen above followed the same five steps, in case new screens get
added later:

1. **Copy or write the visual code** — JSX, styling, and component
   structure don't need to change from a mock, if one exists.
2. **Replace mock constants** with `useState(null)` (or `[]` where a mock
   array was the default) plus a `useEffect` that calls the right
   function from `src/lib/apiClient.js`. If the endpoint isn't in
   `apiClient.js` yet, add a typed helper there first rather than calling
   `api.get(...)` directly in the component.
2. **Add loading/error/empty states** — a moment where `data === null`
   (loading), a moment where the fetch failed, and a moment where the
   list is genuinely empty. `Dashboard.jsx` shows all three.
3. **Real calls, not `console.log`**, inside a `try/catch` that surfaces
   `err.message` to the user rather than throwing silently.
4. **Wrap the route in `<RequireAuth>`** in `App.jsx` and add it to the
   `<Routes>` list, plus a link in Dashboard's nav menu if it should be
   reachable from there.
5. **Handle 401s** by calling `signOut()` from `useAuth()` — an
   expired/invalid token should return the user to the login screen, not
   show a raw error.

The API route each screen needs is documented in the CDK project's
`lib/constructs/api.ts` and in the full documentation's API Route Reference
section.
