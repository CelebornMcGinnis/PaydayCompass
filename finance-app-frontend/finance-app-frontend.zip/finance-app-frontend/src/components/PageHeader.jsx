import React, { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, Home, Menu, X, LogOut } from "lucide-react";
import { NAV_LINKS } from "../lib/navLinks";
import { colors, fontDisplay, fontBody } from "../lib/theme";
import { useAuth } from "../lib/authContext";
import { sharingApi } from "../lib/apiClient";

/**
 * The standard header for every page except Dashboard (which has its own
 * richer version with the net-worth stamp and walkthrough integration,
 * but shares this same NAV_LINKS list for its menu). Shows a back button
 * (browser-history back, for "where I actually came from"), a home
 * button (always the dashboard specifically), the logo, the current
 * page's title, and the same nav menu Dashboard has.
 */
export default function PageHeader({ title, subtitle }) {
  const navigate = useNavigate();
  const { signOut } = useAuth();
  const [menuOpen, setMenuOpen] = useState(false);
  const [hasPendingShares, setHasPendingShares] = useState(false);
  const menuRef = useRef(null);

  useEffect(() => {
    sharingApi
      .list()
      .then((d) => setHasPendingShares((d.asInvited || []).some((s) => s.status === "pending")))
      .catch(() => {}); // best-effort - a failed check just means no dot, not a broken header
  }, []);

  useEffect(() => {
    if (!menuOpen) return;
    function handleClickOutside(e) {
      if (menuRef.current && !menuRef.current.contains(e.target)) {
        setMenuOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [menuOpen]);

  return (
    <div className="sticky top-0 z-30 flex items-center justify-between px-5 py-4" style={{ background: `${colors.bg}E6`, backdropFilter: "blur(8px)", borderBottom: `1px solid ${colors.border}` }}>
      <div className="flex items-center gap-2 min-w-0">
        <button onClick={() => navigate(-1)} aria-label="Back" className="p-1 -ml-1 shrink-0 transition-opacity hover:opacity-70" style={{ color: colors.text }}>
          <ArrowLeft size={20} />
        </button>
        <button onClick={() => navigate("/")} aria-label="Back to dashboard" className="p-1 shrink-0 transition-opacity hover:opacity-70" style={{ color: colors.text }}>
          <Home size={18} />
        </button>
        <img src="/ledgerline-favicon-dark.png" alt="Ledgerline" style={{ width: 26, height: 26 }} className="shrink-0 ml-1" />
        <div className="min-w-0">
          <span className="truncate block" style={{ fontFamily: fontDisplay, color: colors.text, fontSize: 18, fontWeight: 600 }}>{title}</span>
          {subtitle && <span className="text-xs" style={{ color: colors.textMuted }}>{subtitle}</span>}
        </div>
      </div>

      <div className="relative shrink-0" ref={menuRef}>
        <button onClick={() => setMenuOpen((o) => !o)} aria-label="Menu" style={{ color: colors.text }} className="relative transition-opacity hover:opacity-70">
          {menuOpen ? <X size={22} /> : <Menu size={22} />}
          {hasPendingShares && !menuOpen && (
            <span className="absolute rounded-full" style={{ width: 8, height: 8, top: -1, right: -1, background: colors.alert, border: `1.5px solid ${colors.bg}` }} />
          )}
        </button>

        {menuOpen && (
          <div className="absolute right-0 top-9 w-56 rounded-xl p-1.5 shadow-2xl z-40" style={{ background: colors.surfaceRaised, border: `1px solid ${colors.borderStrong}` }}>
            {NAV_LINKS.map((link) => {
              const Icon = link.icon;
              const showDot = link.to === "/sharing" && hasPendingShares;
              return (
                <button
                  key={link.to}
                  onClick={() => { setMenuOpen(false); navigate(link.to); }}
                  className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm text-left transition-opacity hover:opacity-80"
                  style={{ color: colors.text }}
                >
                  <span className="relative">
                    <Icon size={15} style={{ color: colors.textMuted }} />
                    {showDot && <span className="absolute rounded-full" style={{ width: 6, height: 6, top: -2, right: -2, background: colors.alert }} />}
                  </span>
                  {link.label}
                </button>
              );
            })}
            <div className="my-1" style={{ borderTop: `1px solid ${colors.border}` }} />
            <button onClick={signOut} className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm text-left transition-opacity hover:opacity-80" style={{ color: colors.alert }}>
              <LogOut size={15} />
              Sign out
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
