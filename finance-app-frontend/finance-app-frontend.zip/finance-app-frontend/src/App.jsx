import React from "react";
import { BrowserRouter, Routes, Route, Navigate, useLocation } from "react-router-dom";
import { AuthProvider, useAuth } from "./lib/authContext";
import LoginPage from "./pages/Login";
import SignUpPage from "./pages/SignUp";
import DashboardPage from "./pages/Dashboard";
import AddExpensePage from "./pages/AddExpense";
import AccountDetailPage from "./pages/AccountDetail";
import BudgetsPage from "./pages/Budgets";
import PaydayPage from "./pages/Payday";
import CategoryTrendsPage from "./pages/CategoryTrends";
import MfaSetupPage from "./pages/MfaSetup";
import ExternalBankAccountsPage from "./pages/ExternalBankAccounts";
import ManageRecurringPage from "./pages/ManageRecurring";
import SettingsPage from "./pages/Settings";
import GettingSetupPage from "./pages/GettingSetup";
import PlannedExpensesPage from "./pages/PlannedExpenses";
import SharingPage from "./pages/Sharing";
import ScenariosPage from "./pages/Scenarios";
import NotificationsPage from "./pages/Notifications";
import LegalPage from "./pages/Legal";
import NotFoundPage from "./pages/NotFound";
import { colors, fontBody } from "./lib/theme";

function RequireAuth({ children }) {
  const { status, needsSetup } = useAuth();
  const location = useLocation();

  if (status === "checking") {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: colors.bg, fontFamily: fontBody }}>
        <p style={{ color: colors.textMuted, fontSize: 14 }}>Loading…</p>
      </div>
    );
  }
  if (status === "signedOut") {
    return <Navigate to="/login" replace />;
  }
  // A brand-new user (hasCompletedSetup != "true") gets sent to the
  // wizard automatically - except when they're already on it, which
  // would otherwise be an infinite redirect.
  if (needsSetup && location.pathname !== "/getting-setup") {
    return <Navigate to="/getting-setup" replace />;
  }
  return children;
}

function AppRoutes() {
  const { status } = useAuth();

  return (
    <Routes>
      <Route path="/login" element={status === "signedIn" ? <Navigate to="/" replace /> : <LoginPage />} />
      <Route path="/signup" element={status === "signedIn" ? <Navigate to="/" replace /> : <SignUpPage />} />
      <Route path="/" element={<RequireAuth><DashboardPage /></RequireAuth>} />
      <Route path="/add-expense" element={<RequireAuth><AddExpensePage /></RequireAuth>} />
      <Route path="/accounts/:accountId" element={<RequireAuth><AccountDetailPage /></RequireAuth>} />
      <Route path="/budgets" element={<RequireAuth><BudgetsPage /></RequireAuth>} />
      <Route path="/payday" element={<RequireAuth><PaydayPage /></RequireAuth>} />
      <Route path="/trends" element={<RequireAuth><CategoryTrendsPage /></RequireAuth>} />
      <Route path="/settings/mfa" element={<RequireAuth><MfaSetupPage /></RequireAuth>} />
      <Route path="/external-bank-accounts" element={<RequireAuth><ExternalBankAccountsPage /></RequireAuth>} />
      <Route path="/recurring" element={<RequireAuth><ManageRecurringPage /></RequireAuth>} />
      <Route path="/settings" element={<RequireAuth><SettingsPage /></RequireAuth>} />
      <Route path="/getting-setup" element={<RequireAuth><GettingSetupPage /></RequireAuth>} />
      <Route path="/planned-expenses" element={<RequireAuth><PlannedExpensesPage /></RequireAuth>} />
      <Route path="/sharing" element={<RequireAuth><SharingPage /></RequireAuth>} />
      <Route path="/scenarios" element={<RequireAuth><ScenariosPage /></RequireAuth>} />
      <Route path="/notifications" element={<RequireAuth><NotificationsPage /></RequireAuth>} />
      <Route path="/legal" element={<RequireAuth><LegalPage /></RequireAuth>} />
      <Route path="*" element={<NotFoundPage />} />
      {/*
        Remaining screens follow the exact same pattern as Dashboard/AddExpense:
        1. useEffect + the relevant api client call from src/lib/apiClient.js
        2. loading / error / empty states (see Dashboard.jsx)
        3. wrap the route in <RequireAuth>
        See README.md "Wiring the remaining screens" for the full checklist.
      */}
    </Routes>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <AppRoutes />
      </AuthProvider>
    </BrowserRouter>
  );
}
