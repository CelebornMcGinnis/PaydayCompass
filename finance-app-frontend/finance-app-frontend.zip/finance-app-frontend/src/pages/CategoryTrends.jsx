import React, { useEffect, useMemo, useState } from "react";
import { ArrowLeft, HelpCircle } from "lucide-react";
import { LineChart, Line, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer, CartesianGrid } from "recharts";
import { accountsApi, transactionsApi } from "../lib/apiClient";
import { colors, fontDisplay, fontBody, fontMono, formatMoney } from "../lib/theme";
import PageHeader from "../components/PageHeader";

const RANGE_OPTIONS = [
  { key: "3M", label: "3M", months: 3 },
  { key: "6M", label: "6M", months: 6 },
  { key: "1Y", label: "1Y", months: 12 },
  { key: "5Y", label: "5Y", months: 60 },
];

// A fixed, readable palette - categories beyond the top N get folded into
// "Other" rather than the chart growing an unreadable number of lines.
const LINE_COLORS = [colors.accentLight, colors.positive, "#D6A24C", colors.alert, "#8A7FD9", colors.textMuted];
const MAX_CATEGORIES = 5;

function InfoBubble({ text }) {
  const [open, setOpen] = useState(false);
  return (
    <span className="relative inline-flex align-middle ml-1.5">
      <button type="button" onClick={() => setOpen((o) => !o)} aria-label="More information" style={{ width: 16, height: 16, color: colors.textMuted }}>
        <HelpCircle size={14} strokeWidth={2} />
      </button>
      {open && (
        <div className="absolute z-30 left-0 top-6 w-64 rounded-lg p-3 text-xs shadow-xl" style={{ background: colors.surfaceRaised, border: `1px solid ${colors.borderStrong}`, color: colors.text }}>
          {text}
          <button onClick={() => setOpen(false)} className="block mt-2 text-xs underline" style={{ color: colors.accentLight }}>Got it</button>
        </div>
      )}
    </span>
  );
}

function monthKey(dateStr) {
  return dateStr?.slice(0, 7); // "2026-08"
}
function monthLabel(key) {
  const [y, m] = key.split("-");
  return new Date(Number(y), Number(m) - 1, 1).toLocaleDateString("en-US", { month: "short", year: "2-digit" });
}

function CustomTooltip({ active, payload, label }) {
  if (!active || !payload || !payload.length) return null;
  return (
    <div className="rounded-lg px-3 py-2 text-xs shadow-xl" style={{ background: colors.surfaceRaised, border: `1px solid ${colors.borderStrong}`, color: colors.text }}>
      <div style={{ color: colors.textMuted }} className="mb-1">{label}</div>
      {payload.map((p) => (
        <div key={p.dataKey} style={{ color: p.color, fontFamily: fontMono }}>
          {p.dataKey}: {formatMoney(p.value)}
        </div>
      ))}
    </div>
  );
}

export default function CategoryTrendsPage() {
  const [transactions, setTransactions] = useState(null);
  const [error, setError] = useState(null);
  const [range, setRange] = useState("6M");

  useEffect(() => {
    let cancelled = false;
    accountsApi
      .list()
      .then((accounts) => Promise.all(accounts.map((a) => transactionsApi.list(a.accountId))))
      .then((perAccount) => {
        if (cancelled) return;
        setTransactions(perAccount.flat());
      })
      .catch(() => {
        if (!cancelled) setError("Couldn't load your spending history.");
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const { chartData, categories } = useMemo(() => {
    if (!transactions) return { chartData: [], categories: [] };

    const rangeConfig = RANGE_OPTIONS.find((r) => r.key === range);
    const cutoff = new Date();
    cutoff.setMonth(cutoff.getMonth() - rangeConfig.months + 1);
    const cutoffKey = monthKey(cutoff.toISOString());

    // Only real debit spend counts - transfers and credits don't belong
    // in a "where did my money go" trend.
    const relevant = transactions.filter(
      (t) => t.direction === "debit" && !t.isTransfer && monthKey(t.createdAt) >= cutoffKey
    );

    // Rank categories by total spend in-range, keep the top N, fold the rest into "Other"
    const totalsByCategory = {};
    for (const t of relevant) {
      totalsByCategory[t.category] = (totalsByCategory[t.category] || 0) + t.amount;
    }
    const topCategories = Object.entries(totalsByCategory)
      .sort((a, b) => b[1] - a[1])
      .slice(0, MAX_CATEGORIES)
      .map(([cat]) => cat);
    const hasOther = Object.keys(totalsByCategory).length > MAX_CATEGORIES;

    // Build one bucket per month in range, even months with zero spend,
    // so the line doesn't just skip gaps.
    const months = [];
    const cursor = new Date(cutoff);
    cursor.setDate(1);
    const now = new Date();
    while (cursor <= now) {
      months.push(cursor.toISOString().slice(0, 7));
      cursor.setMonth(cursor.getMonth() + 1);
    }

    const buckets = Object.fromEntries(months.map((m) => [m, { month: monthLabel(m) }]));
    for (const t of relevant) {
      const mKey = monthKey(t.createdAt);
      if (!buckets[mKey]) continue;
      const cat = topCategories.includes(t.category) ? t.category : "Other";
      buckets[mKey][cat] = (buckets[mKey][cat] || 0) + t.amount;
    }

    return {
      chartData: months.map((m) => buckets[m]),
      categories: hasOther ? [...topCategories, "Other"] : topCategories,
    };
  }, [transactions, range]);

  return (
    <div className="min-h-screen pb-10" style={{ background: colors.bg, fontFamily: fontBody }}>
      <PageHeader title="Category trends" />

      <div className="px-5 pt-6 max-w-2xl mx-auto">
        <div className="flex items-center mb-2 px-1">
          <h3 style={{ fontFamily: fontDisplay, color: colors.text, fontSize: 15, fontWeight: 600 }}>Spending by category over time</h3>
          <InfoBubble text="Across every account, month by month. The top 5 categories by spend in this range get their own line; everything else is grouped as Other." />
        </div>

        <div className="flex gap-1.5 mb-4 px-1">
          {RANGE_OPTIONS.map((opt) => {
            const active = range === opt.key;
            return (
              <button
                key={opt.key}
                type="button"
                onClick={() => setRange(opt.key)}
                className="rounded-full px-3 py-1 text-xs font-medium transition-colors"
                style={{
                  background: active ? colors.accent : "transparent",
                  color: active ? colors.bg : colors.textMuted,
                  border: `1px solid ${active ? colors.accent : colors.border}`,
                }}
              >
                {opt.label}
              </button>
            );
          })}
        </div>

        {error && <p className="text-sm mb-4" style={{ color: colors.alert }}>{error}</p>}
        {!transactions && !error && <p className="text-sm" style={{ color: colors.textMuted }}>Loading…</p>}

        {transactions && chartData.length > 0 && (
          <div className="rounded-2xl p-3 pt-5" style={{ background: colors.surface, border: `1px solid ${colors.border}`, height: 340 }}>
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={chartData} margin={{ top: 4, right: 12, left: -10, bottom: 0 }}>
                <CartesianGrid stroke={colors.border} vertical={false} />
                <XAxis
                  dataKey="month"
                  tick={{ fill: colors.textMuted, fontSize: 11 }}
                  axisLine={{ stroke: colors.border }}
                  tickLine={false}
                  interval={chartData.length > 8 ? Math.ceil(chartData.length / 8) - 1 : 0}
                />
                <YAxis tick={{ fill: colors.textMuted, fontSize: 10, fontFamily: fontMono }} axisLine={false} tickLine={false} width={50} tickFormatter={(v) => `$${Math.round(v / 100) / 10}k`} />
                <Tooltip content={<CustomTooltip />} />
                <Legend wrapperStyle={{ fontSize: 12, color: colors.textMuted }} />
                {categories.map((cat, i) => (
                  <Line key={cat} type="monotone" dataKey={cat} stroke={LINE_COLORS[i % LINE_COLORS.length]} strokeWidth={2} dot={false} connectNulls />
                ))}
              </LineChart>
            </ResponsiveContainer>
          </div>
        )}

        {transactions && chartData.length === 0 && (
          <p className="text-sm" style={{ color: colors.textMuted }}>No spending in this range yet.</p>
        )}
      </div>
    </div>
  );
}
