import React, { useEffect, useState } from "react";
import { ArrowLeft, Plus, X, HelpCircle, Check, Trash2 } from "lucide-react";
import { accountsApi, recurringApi, scenariosApi } from "../lib/apiClient";
import { colors, fontDisplay, fontBody, fontMono, formatMoney } from "../lib/theme";
import PageHeader from "../components/PageHeader";

function InfoBubble({ text }) {
  const [open, setOpen] = useState(false);
  return (
    <span className="relative inline-flex align-middle ml-1.5">
      <button type="button" onClick={() => setOpen((o) => !o)} aria-label="More information" style={{ width: 16, height: 16, color: colors.textMuted }}>
        <HelpCircle size={14} strokeWidth={2} />
      </button>
      {open && (
        <div className="absolute z-30 left-0 top-6 w-64 rounded-lg p-3 text-xs shadow-xl" style={{ background: colors.surfaceRaised, border: `1px solid ${colors.borderStrong}`, color: colors.text }}>
          {text}
          <button onClick={() => setOpen(false)} className="block mt-2 text-xs underline" style={{ color: colors.accentLight }}>Got it</button>
        </div>
      )}
    </span>
  );
}

function SectionHeader({ children, info }) {
  return (
    <div className="flex items-center mb-2 px-1">
      <h3 style={{ fontFamily: fontDisplay, color: colors.text, fontSize: 15, fontWeight: 600 }}>{children}</h3>
      {info && <InfoBubble text={info} />}
    </div>
  );
}

function AdjustmentRow({ children, onRemove }) {
  return (
    <div className="flex items-center gap-2 mb-2">
      <div className="flex-1 flex gap-2">{children}</div>
      <button onClick={onRemove} aria-label="Remove" style={{ color: colors.alert }}><Trash2 size={15} /></button>
    </div>
  );
}

function uid() {
  return Math.random().toString(36).slice(2, 9);
}

export default function ScenariosPage() {
  const [savedScenarios, setSavedScenarios] = useState(null);
  const [expenseOptions, setExpenseOptions] = useState([]);
  const [error, setError] = useState(null);

  const [name, setName] = useState("");
  const [incomeAdjustments, setIncomeAdjustments] = useState([]);
  const [expenseAdjustments, setExpenseAdjustments] = useState([]);
  const [newExpenses, setNewExpenses] = useState([]);
  const [preview, setPreview] = useState(null);
  const [previewLoading, setPreviewLoading] = useState(false);
  const [saving, setSaving] = useState(false);

  const [selectedForCompare, setSelectedForCompare] = useState([]);
  const [compareResult, setCompareResult] = useState(null);
  const [comparing, setComparing] = useState(false);

  function refresh() {
    scenariosApi.list().then(setSavedScenarios).catch(() => setError("Couldn't load your saved scenarios."));
    accountsApi
      .list()
      .then((accts) => Promise.all(accts.map((a) => recurringApi.list(a.accountId).catch(() => []))))
      .then((perAccount) => setExpenseOptions(perAccount.flat().filter((i) => !i.isIncome)))
      .catch(() => {});
  }
  useEffect(refresh, []);

  function buildAdjustments() {
    return {
      name: name.trim() || undefined,
      incomeAdjustments: incomeAdjustments.filter((a) => a.label && a.monthlyDelta !== "").map((a) => ({ label: a.label, monthlyDelta: parseFloat(a.monthlyDelta) || 0 })),
      expenseAdjustments: expenseAdjustments.filter((a) => a.recurringId && a.monthlyDelta !== "").map((a) => ({ recurringId: a.recurringId, monthlyDelta: parseFloat(a.monthlyDelta) || 0 })),
      newExpenses: newExpenses.filter((e) => e.description && e.monthlyAmount !== "").map((e) => ({ description: e.description, category: e.category || "Uncategorized", monthlyAmount: parseFloat(e.monthlyAmount) || 0 })),
    };
  }

  async function runPreview() {
    setPreviewLoading(true);
    try {
      const result = await scenariosApi.calculateThrowaway(buildAdjustments());
      setPreview(result);
    } catch (err) {
      setError(err.message || "Couldn't calculate that scenario.");
    } finally {
      setPreviewLoading(false);
    }
  }

  async function saveScenario() {
    if (!name.trim()) return;
    setSaving(true);
    setError(null);
    try {
      await scenariosApi.save(buildAdjustments());
      setName("");
      setIncomeAdjustments([]);
      setExpenseAdjustments([]);
      setNewExpenses([]);
      setPreview(null);
      refresh();
    } catch (err) {
      setError(err.message || "Couldn't save that scenario.");
    } finally {
      setSaving(false);
    }
  }

  async function deleteScenario(id) {
    try {
      await scenariosApi.remove(id);
      setSelectedForCompare((s) => s.filter((x) => x !== id));
      refresh();
    } catch (err) {
      setError(err.message || "Couldn't delete that scenario.");
    }
  }

  function toggleCompare(id) {
    setSelectedForCompare((sel) => {
      if (sel.includes(id)) return sel.filter((x) => x !== id);
      if (sel.length >= 6) return sel;
      return [...sel, id];
    });
  }

  async function runCompare() {
    if (selectedForCompare.length === 0) return;
    setComparing(true);
    setError(null);
    try {
      const result = await scenariosApi.compare({ scenarios: selectedForCompare.map((id) => ({ scenarioId: id })) });
      setCompareResult(result);
    } catch (err) {
      setError(err.message || "Couldn't compare those scenarios.");
    } finally {
      setComparing(false);
    }
  }

  return (
    <div className="min-h-screen pb-10" style={{ background: colors.bg, fontFamily: fontBody }}>
      <PageHeader title="Scenarios" />

      <div className="px-5 pt-6 max-w-md mx-auto">
        {error && <p className="text-sm mb-4" style={{ color: colors.alert }}>{error}</p>}

        <SectionHeader info="A scenario is never frozen — it's always recalculated against your real, current income, budgets, and planned expenses, even if you saved it months ago.">
          Build a scenario
        </SectionHeader>

        <div className="rounded-2xl p-4 mb-6" style={{ background: colors.surface, border: `1px solid ${colors.border}` }}>
          <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Name (e.g. If I got a raise)" className="w-full rounded-lg px-3 py-2 text-sm mb-4 focus:outline-none" style={{ background: colors.bg, border: `1px solid ${colors.border}`, color: colors.text }} />

          <p className="text-xs uppercase tracking-wide mb-2" style={{ color: colors.textMuted, letterSpacing: "0.08em" }}>Income changes</p>
          {incomeAdjustments.map((a) => (
            <AdjustmentRow key={a.id} onRemove={() => setIncomeAdjustments((r) => r.filter((x) => x.id !== a.id))}>
              <input value={a.label} onChange={(e) => setIncomeAdjustments((r) => r.map((x) => x.id === a.id ? { ...x, label: e.target.value } : x))} placeholder="Label (e.g. Raise)" className="flex-1 rounded-lg px-2.5 py-1.5 text-sm focus:outline-none" style={{ background: colors.bg, border: `1px solid ${colors.border}`, color: colors.text }} />
              <input type="number" value={a.monthlyDelta} onChange={(e) => setIncomeAdjustments((r) => r.map((x) => x.id === a.id ? { ...x, monthlyDelta: e.target.value } : x))} placeholder="+$/mo" style={{ width: 90, background: colors.bg, border: `1px solid ${colors.border}`, color: colors.text, fontFamily: fontMono }} className="rounded-lg px-2 py-1.5 text-sm focus:outline-none" />
            </AdjustmentRow>
          ))}
          <button onClick={() => setIncomeAdjustments((r) => [...r, { id: uid(), label: "", monthlyDelta: "" }])} className="text-xs mb-4 flex items-center gap-1" style={{ color: colors.accentLight }}><Plus size={12} />Add income change</button>

          <p className="text-xs uppercase tracking-wide mb-2" style={{ color: colors.textMuted, letterSpacing: "0.08em" }}>Adjust an existing expense</p>
          {expenseAdjustments.map((a) => (
            <AdjustmentRow key={a.id} onRemove={() => setExpenseAdjustments((r) => r.filter((x) => x.id !== a.id))}>
              <select value={a.recurringId} onChange={(e) => setExpenseAdjustments((r) => r.map((x) => x.id === a.id ? { ...x, recurringId: e.target.value } : x))} className="flex-1 rounded-lg px-2.5 py-1.5 text-sm focus:outline-none" style={{ background: colors.bg, border: `1px solid ${colors.border}`, color: colors.text }}>
                <option value="">Choose…</option>
                {expenseOptions.map((e) => <option key={e.recurringId} value={e.recurringId}>{e.description}</option>)}
              </select>
              <input type="number" value={a.monthlyDelta} onChange={(e) => setExpenseAdjustments((r) => r.map((x) => x.id === a.id ? { ...x, monthlyDelta: e.target.value } : x))} placeholder="+/-$/mo" style={{ width: 90, background: colors.bg, border: `1px solid ${colors.border}`, color: colors.text, fontFamily: fontMono }} className="rounded-lg px-2 py-1.5 text-sm focus:outline-none" />
            </AdjustmentRow>
          ))}
          <button onClick={() => setExpenseAdjustments((r) => [...r, { id: uid(), recurringId: "", monthlyDelta: "" }])} className="text-xs mb-4 flex items-center gap-1" style={{ color: colors.accentLight }}><Plus size={12} />Adjust an expense</button>

          <p className="text-xs uppercase tracking-wide mb-2" style={{ color: colors.textMuted, letterSpacing: "0.08em" }}>New hypothetical expenses</p>
          {newExpenses.map((e) => (
            <AdjustmentRow key={e.id} onRemove={() => setNewExpenses((r) => r.filter((x) => x.id !== e.id))}>
              <input value={e.description} onChange={(ev) => setNewExpenses((r) => r.map((x) => x.id === e.id ? { ...x, description: ev.target.value } : x))} placeholder="e.g. Gym membership" className="flex-1 rounded-lg px-2.5 py-1.5 text-sm focus:outline-none" style={{ background: colors.bg, border: `1px solid ${colors.border}`, color: colors.text }} />
              <input type="number" value={e.monthlyAmount} onChange={(ev) => setNewExpenses((r) => r.map((x) => x.id === e.id ? { ...x, monthlyAmount: ev.target.value } : x))} placeholder="$/mo" style={{ width: 80, background: colors.bg, border: `1px solid ${colors.border}`, color: colors.text, fontFamily: fontMono }} className="rounded-lg px-2 py-1.5 text-sm focus:outline-none" />
            </AdjustmentRow>
          ))}
          <button onClick={() => setNewExpenses((r) => [...r, { id: uid(), description: "", category: "", monthlyAmount: "" }])} className="text-xs mb-4 flex items-center gap-1" style={{ color: colors.accentLight }}><Plus size={12} />Add hypothetical expense</button>

          <div className="flex gap-2">
            <button onClick={runPreview} disabled={previewLoading} className="flex-1 rounded-lg py-2.5 text-sm font-medium" style={{ border: `1px solid ${colors.border}`, color: colors.text, opacity: previewLoading ? 0.6 : 1 }}>
              {previewLoading ? "Calculating…" : "Preview"}
            </button>
            <button onClick={saveScenario} disabled={!name.trim() || saving} className="flex-1 rounded-lg py-2.5 text-sm font-medium" style={{ background: name.trim() ? colors.accent : colors.surfaceRaised, color: name.trim() ? colors.bg : colors.textMuted, opacity: saving ? 0.6 : 1 }}>
              {saving ? "Saving…" : "Save"}
            </button>
          </div>
        </div>

        {preview && (
          <div className="rounded-2xl p-4 mb-6" style={{ background: colors.surfaceRaised, border: `1px solid ${colors.borderStrong}` }}>
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs" style={{ color: colors.textMuted }}>Projected leftover</span>
              <span style={{ fontFamily: fontMono, color: colors.textMuted, fontSize: 12 }}>was {formatMoney(preview.baseline.projectedLeftover)}</span>
            </div>
            <p style={{ fontFamily: fontMono, fontSize: 22, color: preview.adjusted.projectedLeftover >= 0 ? colors.positive : colors.alert }}>
              {formatMoney(preview.adjusted.projectedLeftover)}
              <span className="text-sm ml-2" style={{ color: preview.leftoverDelta >= 0 ? colors.positive : colors.alert }}>
                ({preview.leftoverDelta >= 0 ? "+" : ""}{formatMoney(preview.leftoverDelta)})
              </span>
            </p>
          </div>
        )}

        <SectionHeader>Saved scenarios</SectionHeader>
        <div className="rounded-2xl mb-4 overflow-hidden" style={{ background: colors.surface, border: `1px solid ${colors.border}` }}>
          {savedScenarios === null && !error ? (
            <p className="text-sm py-4 text-center" style={{ color: colors.textMuted }}>Loading…</p>
          ) : savedScenarios.length === 0 ? (
            <p className="text-sm py-4 text-center" style={{ color: colors.textMuted }}>Nothing saved yet.</p>
          ) : (
            savedScenarios.map((s, i) => (
              <div key={s.scenarioId} className="flex items-center justify-between px-4 py-3" style={{ borderBottom: i < savedScenarios.length - 1 ? `1px solid ${colors.border}` : "none" }}>
                <div className="flex items-center gap-2.5 min-w-0">
                  <button onClick={() => toggleCompare(s.scenarioId)} className="flex items-center justify-center rounded-full shrink-0" style={{ width: 18, height: 18, border: `1.5px solid ${selectedForCompare.includes(s.scenarioId) ? colors.accentLight : colors.borderStrong}`, background: selectedForCompare.includes(s.scenarioId) ? colors.accentLight : "transparent" }}>
                    {selectedForCompare.includes(s.scenarioId) && <Check size={11} style={{ color: colors.bg }} />}
                  </button>
                  <span className="text-sm truncate" style={{ color: colors.text }}>{s.name}</span>
                </div>
                <button onClick={() => deleteScenario(s.scenarioId)} aria-label="Delete" style={{ color: colors.alert }}><Trash2 size={15} /></button>
              </div>
            ))
          )}
        </div>

        {savedScenarios && savedScenarios.length > 0 && (
          <button onClick={runCompare} disabled={selectedForCompare.length === 0 || comparing} className="w-full rounded-2xl py-3 mb-6 text-sm font-medium" style={{ background: selectedForCompare.length > 0 ? colors.accent : colors.surface, color: selectedForCompare.length > 0 ? colors.bg : colors.textMuted, opacity: comparing ? 0.6 : 1 }}>
            {comparing ? "Comparing…" : `Compare ${selectedForCompare.length || ""} selected`}
          </button>
        )}

        {compareResult && (
          <>
            <SectionHeader>Comparison</SectionHeader>
            <div className="rounded-2xl overflow-hidden mb-4" style={{ background: colors.surface, border: `1px solid ${colors.border}` }}>
              <div className="flex items-center justify-between px-4 py-3" style={{ borderBottom: `1px solid ${colors.border}`, background: colors.surfaceRaised }}>
                <span className="text-sm" style={{ color: colors.text }}>Today (baseline)</span>
                <span style={{ fontFamily: fontMono, fontSize: 14, color: colors.text }}>{formatMoney(compareResult.baseline.projectedLeftover)}</span>
              </div>
              {compareResult.scenarios.map((s, i) => (
                <div key={s.scenarioId || i} className="flex items-center justify-between px-4 py-3" style={{ borderBottom: i < compareResult.scenarios.length - 1 ? `1px solid ${colors.border}` : "none" }}>
                  <span className="text-sm truncate pr-2" style={{ color: colors.text }}>{s.name}</span>
                  {s.error ? (
                    <span className="text-xs" style={{ color: colors.alert }}>{s.error}</span>
                  ) : (
                    <span className="flex items-center gap-2 shrink-0">
                      <span style={{ fontFamily: fontMono, fontSize: 14, color: s.adjusted.projectedLeftover >= 0 ? colors.positive : colors.alert }}>{formatMoney(s.adjusted.projectedLeftover)}</span>
                      <span className="text-xs" style={{ color: s.leftoverDelta >= 0 ? colors.positive : colors.alert }}>({s.leftoverDelta >= 0 ? "+" : ""}{formatMoney(s.leftoverDelta)})</span>
                    </span>
                  )}
                </div>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
