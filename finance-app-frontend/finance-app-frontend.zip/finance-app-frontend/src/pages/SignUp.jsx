import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Lock, Check } from "lucide-react";
import { signUp, confirmSignUp, resendConfirmationCode } from "../lib/cognito";
import { useAuth } from "../lib/authContext";
import { colors, fontDisplay, fontBody } from "../lib/theme";

const PASSWORD_RULES = [
  { test: (p) => p.length >= 10, label: "At least 10 characters" },
  { test: (p) => /[a-z]/.test(p), label: "A lowercase letter" },
  { test: (p) => /[A-Z]/.test(p), label: "An uppercase letter" },
  { test: (p) => /[0-9]/.test(p), label: "A number" },
  { test: (p) => /[^A-Za-z0-9]/.test(p), label: "A symbol" },
];

export default function SignUpPage() {
  const navigate = useNavigate();
  const { signIn } = useAuth();
  const [step, setStep] = useState("form"); // "form" | "confirm"
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [code, setCode] = useState("");
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);
  const [resent, setResent] = useState(false);

  const passwordOk = PASSWORD_RULES.every((r) => r.test(password));
  const canSubmit = email.trim() && passwordOk && password === confirmPassword;

  async function handleSignUp(e) {
    e.preventDefault();
    if (!canSubmit) return;
    setError(null);
    setLoading(true);
    try {
      await signUp(email.trim(), password);
      setStep("confirm");
    } catch (err) {
      setError(err.message || "Couldn't create that account.");
    } finally {
      setLoading(false);
    }
  }

  async function handleConfirm(e) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      await confirmSignUp(email.trim(), code);
      // Confirming the code doesn't establish a session by itself - sign
      // in immediately with the same credentials so the user lands
      // straight on the dashboard, which auto-redirects a brand-new user
      // into Getting Setup rather than making them sign in a second time.
      await signIn(email.trim(), password);
      navigate("/");
    } catch (err) {
      setError(err.message || "That code didn't work.");
    } finally {
      setLoading(false);
    }
  }

  async function handleResend() {
    setError(null);
    try {
      await resendConfirmationCode(email.trim());
      setResent(true);
      setTimeout(() => setResent(false), 4000);
    } catch (err) {
      setError(err.message || "Couldn't resend the code.");
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center px-5" style={{ background: colors.bg, fontFamily: fontBody }}>
      <div className="w-full max-w-sm">
        <div className="text-center mb-8">
          <div
            className="inline-flex items-center justify-center rounded-full mb-4 overflow-hidden"
            style={{ width: 56, height: 56, background: colors.surfaceRaised, border: `1px solid ${colors.borderStrong}`, transform: "rotate(-4deg)" }}
          >
            <img src="/ledgerline-favicon-dark.png" alt="" style={{ width: 36, height: 36, transform: "rotate(4deg)" }} />
          </div>
          <h1 style={{ fontFamily: fontDisplay, color: colors.text, fontSize: 26, fontWeight: 600 }}>
            {step === "form" && "Create your account"}
            {step === "confirm" && "Check your email"}
          </h1>
          {step === "confirm" && (
            <p className="text-sm mt-1" style={{ color: colors.textMuted }}>
              We sent a code to {email}
            </p>
          )}
        </div>

        <div className="rounded-2xl p-6" style={{ background: colors.surface, border: `1px solid ${colors.border}` }}>
          {step === "form" && (
            <form onSubmit={handleSignUp}>
              <label className="block text-xs uppercase tracking-wide mb-1.5" style={{ color: colors.textMuted, letterSpacing: "0.08em" }}>Email</label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
                className="w-full rounded-lg px-3 py-2.5 mb-4 text-sm focus:outline-none"
                style={{ background: colors.bg, border: `1px solid ${colors.border}`, color: colors.text }}
              />

              <label className="block text-xs uppercase tracking-wide mb-1.5" style={{ color: colors.textMuted, letterSpacing: "0.08em" }}>Password</label>
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••••"
                className="w-full rounded-lg px-3 py-2.5 mb-2 text-sm focus:outline-none"
                style={{ background: colors.bg, border: `1px solid ${colors.border}`, color: colors.text }}
              />

              {password.length > 0 && (
                <div className="mb-3 space-y-1">
                  {PASSWORD_RULES.map((r) => {
                    const ok = r.test(password);
                    return (
                      <div key={r.label} className="flex items-center gap-1.5 text-xs" style={{ color: ok ? colors.positive : colors.textMuted }}>
                        <Check size={11} style={{ opacity: ok ? 1 : 0.3 }} />
                        {r.label}
                      </div>
                    );
                  })}
                </div>
              )}

              <label className="block text-xs uppercase tracking-wide mb-1.5" style={{ color: colors.textMuted, letterSpacing: "0.08em" }}>Confirm password</label>
              <input
                type="password"
                required
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="••••••••••"
                className="w-full rounded-lg px-3 py-2.5 mb-3 text-sm focus:outline-none"
                style={{ background: colors.bg, border: `1px solid ${confirmPassword && confirmPassword !== password ? colors.alert : colors.border}`, color: colors.text }}
              />
              {confirmPassword && confirmPassword !== password && (
                <p className="text-xs mb-3" style={{ color: colors.alert }}>Passwords don't match</p>
              )}

              {error && <p className="text-xs mb-3" style={{ color: colors.alert }}>{error}</p>}

              <button
                type="submit"
                disabled={!canSubmit || loading}
                className="w-full rounded-lg py-2.5 text-sm font-medium transition-opacity"
                style={{ background: colors.accent, color: colors.bg, opacity: !canSubmit || loading ? 0.6 : 1 }}
              >
                {loading ? "Creating account…" : "Create account"}
              </button>
            </form>
          )}

          {step === "confirm" && (
            <form onSubmit={handleConfirm}>
              <input
                type="text"
                inputMode="numeric"
                autoFocus
                required
                maxLength={6}
                value={code}
                onChange={(e) => setCode(e.target.value.replace(/\D/g, ""))}
                placeholder="000000"
                className="w-full rounded-lg px-3 py-3 mb-4 text-center text-2xl tracking-[0.3em] focus:outline-none"
                style={{ background: colors.bg, border: `1px solid ${colors.border}`, color: colors.text, fontFamily: "monospace" }}
              />
              {error && <p className="text-xs mb-3" style={{ color: colors.alert }}>{error}</p>}
              {resent && <p className="text-xs mb-3" style={{ color: colors.positive }}>Code resent.</p>}
              <button
                type="submit"
                disabled={code.length !== 6 || loading}
                className="w-full rounded-lg py-2.5 text-sm font-medium mb-3"
                style={{ background: colors.accent, color: colors.bg, opacity: code.length !== 6 || loading ? 0.6 : 1 }}
              >
                {loading ? "Confirming…" : "Confirm"}
              </button>
              <button type="button" onClick={handleResend} className="w-full text-xs" style={{ color: colors.textMuted }}>
                Resend code
              </button>
            </form>
          )}

          {step === "form" && (
            <div className="flex items-center justify-center gap-1.5 mt-5 text-xs" style={{ color: colors.textMuted }}>
              <Lock size={12} />
              <span>Your data stays private to your account</span>
            </div>
          )}
        </div>

        <p className="text-center text-sm mt-5" style={{ color: colors.textMuted }}>
          Already have an account?{" "}
          <button onClick={() => navigate("/login")} className="underline" style={{ color: colors.accentLight }}>
            Sign in
          </button>
        </p>
      </div>
    </div>
  );
}
