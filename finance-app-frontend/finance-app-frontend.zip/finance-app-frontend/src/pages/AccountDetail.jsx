import React, { useEffect, useMemo, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { ArrowLeft, Wallet, ArrowUpRight, ArrowDownLeft, Repeat, HelpCircle, Plus, Users } from "lucide-react";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, BarChart, Bar, CartesianGrid } from "recharts";
import { accountsApi, transactionsApi } from "../lib/apiClient";
import { colors, fontDisplay, fontBody, fontMono, formatMoney } from "../lib/theme";
import PageHeader from "../components/PageHeader";

function InfoBubble({ text }) {
  const [open, setOpen] = useState(false);
  return (
    <span className="relative inline-flex align-middle ml-1.5">
      <button type="button" onClick={() => setOpen((o) => !o)} aria-label="More information" style={{ width: 16, height: 16, color: colors.textMuted }}>
        <HelpCircle size={14} strokeWidth={2} />
      </button>
      {open && (
        <div className="absolute z-30 left-0 top-6 w-60 rounded-lg p-3 text-xs shadow-xl" style={{ background: colors.surfaceRaised, border: `1px solid ${colors.borderStrong}`, color: colors.text }}>
          {text}
          <button onClick={() => setOpen(false)} className="block mt-2 text-xs underline" style={{ color: colors.accentLight }}>Got it</button>
        </div>
      )}
    </span>
  );
}

function PerfEdge() {
  return <div className="absolute top-0 left-0 right-0 h-px" style={{ backgroundImage: `repeating-linear-gradient(90deg, ${colors.borderStrong} 0, ${colors.borderStrong} 5px, transparent 5px, transparent 11px)` }} />;
}

function CustomTooltip({ active, payload, label }) {
  if (!active || !payload || !payload.length) return null;
  return (
    <div className="rounded-lg px-3 py-2 text-xs shadow-xl" style={{ background: colors.surfaceRaised, border: `1px solid ${colors.borderStrong}`, color: colors.text }}>
      <div style={{ color: colors.textMuted }}>{label}</div>
      <div style={{ fontFamily: fontMono }}>{formatMoney(payload[0].value)}</div>
    </div>
  );
}

function TransactionRow({ txn }) {
  const isCredit = txn.direction === "credit";
  const Icon = txn.isTransfer ? Repeat : isCredit ? ArrowDownLeft : ArrowUpRight;
  const iconColor = txn.isTransfer ? colors.textMuted : isCredit ? colors.positive : colors.alert;
  return (
    <div className="flex items-center justify-between py-3 px-1" style={{ borderBottom: `1px solid ${colors.border}` }}>
      <div className="flex items-center gap-3 min-w-0">
        <div className="flex items-center justify-center rounded-lg shrink-0" style={{ width: 32, height: 32, background: colors.surfaceRaised, color: iconColor }}>
          <Icon size={15} strokeWidth={2} />
        </div>
        <div className="min-w-0">
          <p className="text-sm truncate" style={{ color: colors.text }}>{txn.description || txn.category}</p>
          <p className="text-xs" style={{ color: colors.textMuted }}>
            {txn.createdAt?.slice(0, 10)} · {txn.category}
            {txn.source === "recurring" && " · recurring"}
            {txn.isBalanceAdjustment && " · adjustment"}
            {txn.isRetroactiveEntry && " · backfilled for trends"}
          </p>
        </div>
      </div>
      <span className="shrink-0 pl-3 text-sm" style={{ fontFamily: fontMono, color: isCredit ? colors.positive : colors.text }}>
        {isCredit ? "+" : "\u2212"}{formatMoney(txn.amount)}
      </span>
    </div>
  );
}

export default function AccountDetailPage() {
  const navigate = useNavigate();
  const { accountId } = useParams();
  const [account, setAccount] = useState(null);
  const [transactions, setTransactions] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    let cancelled = false;
    Promise.all([accountsApi.list(), transactionsApi.list(accountId)])
      .then(([accounts, txns]) => {
        if (cancelled) return;
        setAccount(accounts.find((a) => a.accountId === accountId) || null);
        setTransactions(txns);
      })
      .catch(() => {
        if (!cancelled) setError("Couldn't load this account's data.");
      });
    return () => {
      cancelled = true;
    };
  }, [accountId]);

  // Derived from REAL transaction history, not fabricated: walk backward
  // from the current balance, undoing each transaction's effect, to
  // reconstruct what the balance was at each prior point in time.
  const trendData = useMemo(() => {
    if (!account || !transactions) return [];
    // Retroactive backfill entries (see ManageRecurring/Budgets' past-date
    // confirmation flow) are explicitly excluded here - they were never
    // reflected in the real balance, so including them would reconstruct
    // balance dips/gains that never actually happened. They still count
    // normally in category breakdown below, which is about real spend,
    // not balance reconstruction.
    const sorted = [...transactions]
      .filter((t) => !t.isRetroactiveEntry)
      .sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1)); // newest first
    let running = account.balance;
    const points = [{ label: "Now", balance: running }];
    for (const t of sorted) {
      running = t.direction === "credit" ? running - t.amount : running + t.amount;
      points.push({ label: t.createdAt?.slice(5, 10) || "", balance: running });
    }
    return points.reverse().slice(-30); // most recent 30 points, oldest to newest
  }, [account, transactions]);

  const categoryBreakdown = useMemo(() => {
    if (!transactions) return [];
    const thisMonth = new Date().toISOString().slice(0, 7);
    const totals = {};
    for (const t of transactions) {
      if (t.direction !== "debit" || t.isTransfer) continue;
      if (!t.createdAt?.startsWith(thisMonth)) continue;
      totals[t.category] = (totals[t.category] || 0) + t.amount;
    }
    return Object.entries(totals)
      .map(([category, amount]) => ({ category, amount }))
      .sort((a, b) => b.amount - a.amount)
      .slice(0, 8);
  }, [transactions]);

  const totalSpend = categoryBreakdown.reduce((s, c) => s + c.amount, 0);

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center px-5" style={{ background: colors.bg }}>
        <p className="text-sm" style={{ color: colors.alert }}>{error}</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen pb-10" style={{ background: colors.bg, fontFamily: fontBody }}>
      <PageHeader title={account ? account.name : "Loading…"} />

      {account && (
        <div className="px-5 pt-5 max-w-md mx-auto">
          {account.sharedFromUserId && (
            <div className="flex items-center gap-1.5 mb-3 px-1">
              <Users size={13} style={{ color: colors.accentLight }} />
              <span className="text-xs" style={{ color: colors.accentLight }}>
                Shared with you{account.sharedPermission ? ` · ${account.sharedPermission}` : ""} — not an account you own
              </span>
            </div>
          )}
          <div className="rounded-2xl p-5 mb-5 relative overflow-hidden" style={{ background: colors.surface, border: `1px solid ${colors.border}` }}>
            <PerfEdge />
            <p className="text-xs uppercase tracking-wide mb-1.5" style={{ color: colors.textMuted, letterSpacing: "0.08em" }}>Current balance</p>
            <p style={{ fontFamily: fontMono, fontSize: 30, color: colors.text }}>{formatMoney(account.balance)}</p>
          </div>

          <button
            type="button"
            onClick={() => navigate(`/add-expense?accountId=${accountId}`)}
            className="w-full rounded-2xl py-3 mb-6 text-sm font-medium flex items-center justify-center gap-2 transition-opacity hover:opacity-90"
            style={{ background: colors.accent, color: colors.bg }}
          >
            <Plus size={16} />
            Add an expense to this account
          </button>

          <div className="mb-6">
            <div className="flex items-center mb-2 px-1">
              <h3 style={{ fontFamily: fontDisplay, color: colors.text, fontSize: 15, fontWeight: 600 }}>Balance trend</h3>
              <InfoBubble text="Reconstructed from your actual transaction history, working backward from today's balance - the last 30 changes on this account." />
            </div>
            {trendData.length > 1 ? (
              <div className="rounded-2xl p-3 pt-4" style={{ background: colors.surface, border: `1px solid ${colors.border}`, height: 160 }}>
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={trendData} margin={{ top: 4, right: 8, left: -18, bottom: 0 }}>
                    <CartesianGrid stroke={colors.border} vertical={false} />
                    <XAxis dataKey="label" tick={{ fill: colors.textMuted, fontSize: 10 }} axisLine={{ stroke: colors.border }} tickLine={false} interval={Math.ceil(trendData.length / 6)} />
                    <YAxis tick={{ fill: colors.textMuted, fontSize: 10, fontFamily: fontMono }} axisLine={false} tickLine={false} width={44} tickFormatter={(v) => `$${Math.round(v / 100) / 10}k`} />
                    <Tooltip content={<CustomTooltip />} />
                    <Line type="monotone" dataKey="balance" stroke={colors.accentLight} strokeWidth={2} dot={false} activeDot={{ r: 5 }} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <p className="text-sm" style={{ color: colors.textMuted }}>Not enough transaction history yet to chart a trend.</p>
            )}
          </div>

          <div className="mb-6">
            <div className="flex items-center mb-2 px-1">
              <h3 style={{ fontFamily: fontDisplay, color: colors.text, fontSize: 15, fontWeight: 600 }}>Spending by category</h3>
              <InfoBubble text="This account's debits this calendar month, grouped by category. Transfers aren't counted." />
              <span className="text-xs ml-auto" style={{ color: colors.textMuted }}>{formatMoney(totalSpend)} total</span>
            </div>
            {categoryBreakdown.length > 0 ? (
              <div className="rounded-2xl p-3 pt-4" style={{ background: colors.surface, border: `1px solid ${colors.border}`, height: 170 }}>
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={categoryBreakdown} layout="vertical" margin={{ top: 0, right: 16, left: 4, bottom: 0 }}>
                    <XAxis type="number" hide />
                    <YAxis dataKey="category" type="category" tick={{ fill: colors.text, fontSize: 11 }} axisLine={false} tickLine={false} width={92} />
                    <Tooltip content={<CustomTooltip />} cursor={{ fill: colors.border }} />
                    <Bar dataKey="amount" fill={colors.accent} radius={[0, 6, 6, 0]} barSize={14} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <p className="text-sm" style={{ color: colors.textMuted }}>No spending on this account yet this month.</p>
            )}
          </div>

          <div>
            <h3 style={{ fontFamily: fontDisplay, color: colors.text, fontSize: 15, fontWeight: 600 }} className="mb-1 px-1">Transactions</h3>
            <div className="rounded-2xl px-4 relative overflow-hidden" style={{ background: colors.surface, border: `1px solid ${colors.border}` }}>
              <PerfEdge />
              <div className="pt-1">
                {transactions.length === 0 ? (
                  <p className="text-sm py-6 text-center" style={{ color: colors.textMuted }}>No transactions yet.</p>
                ) : (
                  [...transactions]
                    .sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1))
                    .map((t) => <TransactionRow key={t.txnId} txn={t} />)
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
