import React, { useEffect, useRef, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { Wallet, PiggyBank, CreditCard, TrendingUp, Landmark, Menu, X, Plus, ChevronRight, ChevronDown, HelpCircle, LogOut } from "lucide-react";
import { accountsApi, sharingApi, ApiError } from "../lib/apiClient";
import { colors, fontDisplay, fontBody, fontMono, formatMoney } from "../lib/theme";
import { useAuth } from "../lib/authContext";
import Walkthrough from "../components/Walkthrough";

const ICONS = { checking: Wallet, savings: PiggyBank, credit: CreditCard, investment: TrendingUp, other: Landmark };
const ACCOUNT_TYPES = [
  { value: "checking", label: "Checking" },
  { value: "savings", label: "Savings" },
  // credit/investment/other intentionally hidden for now - re-add when ready
];
import { NAV_LINKS } from "../lib/navLinks";

function InfoBubble({ text }) {
  const [open, setOpen] = useState(false);
  return (
    <span className="relative inline-flex align-middle ml-1.5">
      <button type="button" onClick={() => setOpen((o) => !o)} aria-label="More information" style={{ width: 16, height: 16, color: colors.textMuted }}>
        <HelpCircle size={14} strokeWidth={2} />
      </button>
      {open && (
        <div className="absolute z-30 left-1/2 -translate-x-1/2 top-6 w-56 rounded-lg p-3 text-xs shadow-xl" style={{ background: colors.surfaceRaised, border: `1px solid ${colors.borderStrong}`, color: colors.text }}>
          {text}
          <button onClick={() => setOpen(false)} className="block mt-2 text-xs underline" style={{ color: colors.accentLight }}>Got it</button>
        </div>
      )}
    </span>
  );
}

function PerfEdge() {
  return <div className="absolute top-0 left-0 right-0 h-px" style={{ backgroundImage: `repeating-linear-gradient(90deg, ${colors.borderStrong} 0, ${colors.borderStrong} 5px, transparent 5px, transparent 11px)` }} />;
}

function AccountCard({ account, onClick }) {
  const Icon = ICONS[account.type] || Landmark;
  const negative = account.balance < 0;
  return (
    <button onClick={onClick} type="button" className="w-full text-left rounded-2xl p-4 relative overflow-hidden mb-3 transition-transform active:scale-[0.99]" style={{ background: colors.surface, border: `1px solid ${colors.border}` }}>
      <PerfEdge />
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3 min-w-0">
          <div className="flex items-center justify-center rounded-xl shrink-0" style={{ width: 40, height: 40, background: colors.surfaceRaised, color: colors.accentLight }}>
            <Icon size={18} strokeWidth={1.75} />
          </div>
          <div className="min-w-0">
            <p className="text-sm font-medium truncate" style={{ color: colors.text }}>{account.name}</p>
            <p className="text-xs capitalize" style={{ color: colors.textMuted }}>{account.type}</p>
          </div>
        </div>
        <div className="flex items-center gap-2 shrink-0 pl-3">
          <span style={{ fontFamily: fontMono, fontSize: 15, color: negative ? colors.alert : colors.text }}>{formatMoney(account.balance)}</span>
          <ChevronRight size={16} style={{ color: colors.textMuted }} />
        </div>
      </div>
    </button>
  );
}

export default function DashboardPage() {
  const navigate = useNavigate();
  const { signOut } = useAuth();
  const [searchParams, setSearchParams] = useSearchParams();
  const [accounts, setAccounts] = useState(null); // null = loading
  const [error, setError] = useState(null);
  const [menuOpen, setMenuOpen] = useState(false);
  const [hasPendingShares, setHasPendingShares] = useState(false);
  const [addingAccount, setAddingAccount] = useState(false);
  const [newAccountName, setNewAccountName] = useState("");
  const [newAccountType, setNewAccountType] = useState("checking");
  const [newAccountBalance, setNewAccountBalance] = useState("");
  const [savingAccount, setSavingAccount] = useState(false);
  const [showWalkthrough, setShowWalkthrough] = useState(searchParams.get("tour") === "1");

  const netWorthRef = useRef(null);
  const accountsListRef = useRef(null);
  const addAccountRef = useRef(null);
  const menuButtonRef = useRef(null);
  const menuContainerRef = useRef(null);
  const navItemEls = useRef({}); // { [link.to]: HTMLElement } - populated as the menu renders
  function navItemRef(key) {
    // A ref-like object whose .current always reflects the latest
    // element for this nav item, even though the item only exists in the
    // DOM while the menu is open - a plain useRef per item isn't possible
    // here since NAV_LINKS is dynamic-length.
    return { get current() { return navItemEls.current[key] || null; } };
  }

  const walkthroughSteps = [
    { ref: netWorthRef, title: "Your net worth", body: "This stamp totals every account you've added. It updates the moment a balance changes." },
    { ref: accountsListRef, title: "Your accounts", body: "Tap any account to see its transactions, spending trends, and category breakdown." },
    { ref: addAccountRef, title: "Adding an account", body: "Add as many as you actually use — checking, savings, credit cards, whatever's real for you." },
    { ref: menuButtonRef, title: "Getting around", body: "Everything else lives behind this menu. Let's take a quick look at what's here." },
    ...NAV_LINKS.map((link) => ({ ref: navItemRef(link.to), title: link.label, body: link.description })),
  ];

  // The menu only needs to be open for the "Getting around" step and
  // every nav-item step after it - open right when that section starts,
  // close again once the tour moves past the last nav item (or ends).
  function handleWalkthroughStepChange(stepIndex) {
    const menuSectionStart = 3; // index of the "Getting around" step above
    const inMenuSection = stepIndex >= menuSectionStart && stepIndex < walkthroughSteps.length;
    setMenuOpen(inMenuSection);
  }

  function endWalkthrough() {
    setShowWalkthrough(false);
    setMenuOpen(false);
    searchParams.delete("tour");
    setSearchParams(searchParams, { replace: true });
  }

  function loadAccounts() {
    accountsApi
      .list()
      .then((data) => setAccounts(data))
      .catch((err) => {
        if (err instanceof ApiError && err.status === 401) {
          signOut(); // token expired/invalid - back to login
        } else {
          setError("Couldn't load your accounts. Pull to refresh, or try again shortly.");
        }
      });
  }

  useEffect(() => {
    loadAccounts();
    sharingApi
      .list()
      .then((d) => setHasPendingShares((d.asInvited || []).some((s) => s.status === "pending")))
      .catch(() => {}); // best-effort - a failed check just means no dot, not a broken dashboard
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!menuOpen) return;
    function handleClickOutside(e) {
      if (menuContainerRef.current && !menuContainerRef.current.contains(e.target)) {
        setMenuOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [menuOpen]);

  const netWorth = (accounts || []).reduce((sum, a) => sum + a.balance, 0);

  async function createAccount() {
    if (!newAccountName.trim()) return;
    setSavingAccount(true);
    try {
      await accountsApi.create({
        name: newAccountName.trim(),
        type: newAccountType,
        balance: parseFloat(newAccountBalance) || 0,
      });
      setNewAccountName("");
      setNewAccountBalance("");
      setAddingAccount(false);
      loadAccounts();
    } catch (err) {
      setError(err.message || "Couldn't create that account.");
    } finally {
      setSavingAccount(false);
    }
  }

  return (
    <div className="min-h-screen pb-24" style={{ background: colors.bg, fontFamily: fontBody }}>
      <div className="sticky top-0 z-30 flex items-center justify-between px-5 py-4" style={{ background: `${colors.bg}E6`, backdropFilter: "blur(8px)", borderBottom: `1px solid ${colors.border}` }}>
        <div className="flex items-center gap-2">
          <img src="/ledgerline-favicon-dark.png" alt="" style={{ width: 22, height: 22 }} />
          <span style={{ fontFamily: fontDisplay, color: colors.text, fontSize: 20, fontWeight: 600 }}>Ledgerline</span>
        </div>
        <div className="relative" ref={menuContainerRef}>
          <button ref={menuButtonRef} onClick={() => setMenuOpen((o) => !o)} aria-label="Menu" style={{ color: colors.text }} className="relative transition-opacity hover:opacity-70">
            {menuOpen ? <X size={22} /> : <Menu size={22} />}
            {hasPendingShares && !menuOpen && (
              <span className="absolute rounded-full" style={{ width: 8, height: 8, top: -1, right: -1, background: colors.alert, border: `1.5px solid ${colors.bg}` }} />
            )}
          </button>
          {menuOpen && (
            <div className="absolute right-0 top-9 w-56 rounded-xl p-1.5 shadow-2xl z-40" style={{ background: colors.surfaceRaised, border: `1px solid ${colors.borderStrong}` }}>
              {NAV_LINKS.map((link) => {
                const Icon = link.icon;
                const showDot = link.to === "/sharing" && hasPendingShares;
                return (
                  <button
                    key={link.to}
                    ref={(el) => (navItemEls.current[link.to] = el)}
                    onClick={() => { setMenuOpen(false); navigate(link.to); }}
                    className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm text-left transition-opacity hover:opacity-80"
                    style={{ color: colors.text }}
                  >
                    <span className="relative">
                      <Icon size={15} style={{ color: colors.textMuted }} />
                      {showDot && <span className="absolute rounded-full" style={{ width: 6, height: 6, top: -2, right: -2, background: colors.alert }} />}
                    </span>
                    {link.label}
                  </button>
                );
              })}
              <div className="my-1" style={{ borderTop: `1px solid ${colors.border}` }} />
              <button onClick={signOut} className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm text-left transition-opacity hover:opacity-80" style={{ color: colors.alert }}>
                <LogOut size={15} />
                Sign out
              </button>
            </div>
          )}
        </div>
      </div>

      <div className="px-5 pt-6 max-w-md mx-auto">
        {accounts !== null && (
          <div ref={netWorthRef} className="flex flex-col items-center mb-8">
            <div
              className="flex flex-col items-center justify-center rounded-full"
              style={{ width: 148, height: 148, border: `2px solid ${colors.accentLight}`, transform: "rotate(-3deg)", boxShadow: `0 0 0 4px ${colors.bg}, 0 0 0 5px ${colors.border}` }}
            >
              <span className="text-[10px] uppercase tracking-widest mb-1" style={{ color: colors.accentLight, letterSpacing: "0.15em" }}>Net worth</span>
              <span style={{ fontFamily: fontMono, fontSize: 22, color: colors.text }}>{formatMoney(netWorth)}</span>
            </div>
          </div>
        )}

        <div className="flex items-center mb-3 px-1">
          <h2 style={{ fontFamily: fontDisplay, color: colors.text, fontSize: 18, fontWeight: 600 }}>Your accounts</h2>
          <InfoBubble text="Tap any account to see its transactions, spending trends, and category breakdown." />
        </div>

        {error && (
          <p className="text-sm mb-4" style={{ color: colors.alert }}>{error}</p>
        )}

        {accounts === null && !error && (
          <p className="text-sm" style={{ color: colors.textMuted }}>Loading your accounts…</p>
        )}

        {accounts !== null && accounts.length === 0 && (
          <p className="text-sm mb-4" style={{ color: colors.textMuted }}>No accounts yet — add your first one below.</p>
        )}

        <div ref={accountsListRef}>
          {(accounts || []).map((a) => (
            <AccountCard key={a.accountId} account={a} onClick={() => navigate(`/accounts/${a.accountId}`)} />
          ))}
        </div>

        <div ref={addAccountRef}>
          {addingAccount ? (
            <div className="rounded-2xl p-4 mt-1" style={{ background: colors.surfaceRaised, border: `1px solid ${colors.borderStrong}` }}>
              <input
                autoFocus
                value={newAccountName}
                onChange={(e) => setNewAccountName(e.target.value)}
                placeholder="e.g. Everyday Checking"
                className="w-full rounded-lg px-3 py-2 text-sm mb-2 focus:outline-none"
                style={{ background: colors.bg, border: `1px solid ${colors.border}`, color: colors.text }}
              />
              <div className="flex gap-2 mb-3">
                <div className="relative flex-1">
                  <select
                    value={newAccountType}
                    onChange={(e) => setNewAccountType(e.target.value)}
                    className="w-full appearance-none rounded-lg px-3 py-2 text-sm focus:outline-none"
                    style={{ background: colors.bg, border: `1px solid ${colors.border}`, color: colors.text }}
                  >
                    {ACCOUNT_TYPES.map((t) => <option key={t.value} value={t.value}>{t.label}</option>)}
                  </select>
                  <ChevronDown size={14} className="absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" style={{ color: colors.textMuted }} />
                </div>
                <div className="relative flex-1">
                  <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-xs" style={{ color: colors.textMuted, fontFamily: fontMono }}>$</span>
                  <input
                    type="number"
                    inputMode="decimal"
                    value={newAccountBalance}
                    onChange={(e) => setNewAccountBalance(e.target.value)}
                    placeholder="0.00"
                    className="w-full rounded-lg pl-5 pr-2 py-2 text-sm focus:outline-none"
                    style={{ background: colors.bg, border: `1px solid ${colors.border}`, color: colors.text, fontFamily: fontMono }}
                  />
                </div>
              </div>
              <div className="flex gap-2">
                <button onClick={() => setAddingAccount(false)} className="flex-1 rounded-lg py-2 text-xs font-medium" style={{ border: `1px solid ${colors.border}`, color: colors.textMuted }}>Cancel</button>
                <button onClick={createAccount} disabled={!newAccountName.trim() || savingAccount} className="flex-1 rounded-lg py-2 text-xs font-medium" style={{ background: colors.accent, color: colors.bg, opacity: savingAccount ? 0.6 : 1 }}>
                  {savingAccount ? "Saving…" : "Save"}
                </button>
              </div>
            </div>
          ) : (
            <button
              onClick={() => setAddingAccount(true)}
              className="w-full rounded-2xl py-3.5 mt-1 text-sm font-medium flex items-center justify-center gap-2 transition-opacity hover:opacity-90"
              style={{ border: `1px dashed ${colors.borderStrong}`, color: colors.textMuted }}
            >
              <Plus size={16} />
              Add an account
            </button>
          )}
        </div>
      </div>

      {showWalkthrough && <Walkthrough steps={walkthroughSteps} onFinish={endWalkthrough} onStepChange={handleWalkthroughStepChange} />}
    </div>
  );
}
