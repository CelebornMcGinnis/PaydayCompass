import React, { useEffect, useState } from "react";
import { ArrowLeft, Plus, ChevronDown, X, HelpCircle } from "lucide-react";
import { plannedExpensesApi, accountsApi } from "../lib/apiClient";
import { colors, fontDisplay, fontBody, fontMono, formatMoney } from "../lib/theme";
import PageHeader from "../components/PageHeader";

const CATEGORY_OPTIONS = ["Gifts", "Travel", "Insurance", "Home", "Auto", "Health", "Other"];
const CONTRIBUTION_FREQUENCIES = [
  { value: "weekly", label: "Weekly" },
  { value: "biweekly", label: "Every 2 weeks" },
  { value: "monthly", label: "Monthly" },
];

function InfoBubble({ text }) {
  const [open, setOpen] = useState(false);
  return (
    <span className="relative inline-flex align-middle ml-1.5">
      <button type="button" onClick={() => setOpen((o) => !o)} aria-label="More information" style={{ width: 16, height: 16, color: colors.textMuted }}>
        <HelpCircle size={14} strokeWidth={2} />
      </button>
      {open && (
        <div className="absolute z-30 left-0 top-6 w-64 rounded-lg p-3 text-xs shadow-xl" style={{ background: colors.surfaceRaised, border: `1px solid ${colors.borderStrong}`, color: colors.text }}>
          {text}
          <button onClick={() => setOpen(false)} className="block mt-2 text-xs underline" style={{ color: colors.accentLight }}>Got it</button>
        </div>
      )}
    </span>
  );
}

function PerfEdge() {
  return <div className="absolute top-0 left-0 right-0 h-px" style={{ backgroundImage: `repeating-linear-gradient(90deg, ${colors.borderStrong} 0, ${colors.borderStrong} 5px, transparent 5px, transparent 11px)` }} />;
}

function PlannedExpenseCard({ item, onEdit, onDelete }) {
  const percent = item.targetAmount > 0 ? Math.min((item.amountSaved / item.targetAmount) * 100, 100) : 0;
  return (
    <div className="rounded-2xl p-4 mb-3 relative overflow-hidden" style={{ background: colors.surface, border: `1px solid ${colors.border}` }}>
      <PerfEdge />
      <div className="flex items-start justify-between mb-2">
        <div className="min-w-0">
          <p className="text-sm font-medium truncate" style={{ color: colors.text }}>{item.name}</p>
          <p className="text-xs" style={{ color: colors.textMuted }}>
            {item.category} · due {item.targetDate}
            {item.recurrenceType === "annual" && " · annual"}
          </p>
        </div>
        <div className="flex items-center gap-2 shrink-0 pl-2">
          <button onClick={() => onEdit(item)} className="text-xs underline" style={{ color: colors.accentLight }}>Edit</button>
          <button onClick={() => onDelete(item)} className="text-xs underline" style={{ color: colors.alert }}>Delete</button>
        </div>
      </div>
      <div className="h-2 rounded-full overflow-hidden mb-2" style={{ background: colors.surfaceRaised }}>
        <div className="h-full rounded-full" style={{ width: `${percent}%`, background: colors.accentLight }} />
      </div>
      <div className="flex items-center justify-between text-xs" style={{ fontFamily: fontMono, color: colors.textMuted }}>
        <span>{formatMoney(item.amountSaved)} of {formatMoney(item.targetAmount)}</span>
        <span style={{ color: colors.accentLight }}>{formatMoney(item.suggestedContribution)}/{item.contributionFrequency === "biweekly" ? "2wk" : item.contributionFrequency === "weekly" ? "wk" : "mo"}</span>
      </div>
    </div>
  );
}

function PlannedExpenseForm({ accounts, initial, onCancel, onSave, saving }) {
  const isEditing = !!initial;
  const [name, setName] = useState(initial?.name ?? "");
  const [category, setCategory] = useState(initial?.category ?? CATEGORY_OPTIONS[0]);
  const [targetAmount, setTargetAmount] = useState(initial?.targetAmount != null ? String(initial.targetAmount) : "");
  const [amountSaved, setAmountSaved] = useState(initial?.amountSaved != null ? String(initial.amountSaved) : "0");
  const [targetDate, setTargetDate] = useState(initial?.targetDate ?? "");
  const [recurrenceType, setRecurrenceType] = useState(initial?.recurrenceType ?? "one_time");
  const [contributionFrequency, setContributionFrequency] = useState(initial?.contributionFrequency ?? "monthly");
  const [linkedAccountId, setLinkedAccountId] = useState(initial?.linkedAccountId ?? "");
  const [notes, setNotes] = useState(initial?.notes ?? "");

  const canSave = name.trim() && parseFloat(targetAmount) > 0 && targetDate;

  function buildPayload() {
    return {
      name: name.trim(),
      category,
      targetAmount: parseFloat(targetAmount),
      amountSaved: parseFloat(amountSaved) || 0,
      targetDate,
      recurrenceType,
      contributionFrequency,
      linkedAccountId: linkedAccountId || null,
      notes: notes.trim(),
    };
  }

  return (
    <div className="rounded-2xl p-4 mb-5" style={{ background: colors.surfaceRaised, border: `1px solid ${colors.borderStrong}` }}>
      <div className="flex items-center justify-between mb-3">
        <span style={{ fontFamily: fontDisplay, color: colors.text, fontSize: 15, fontWeight: 600 }}>{isEditing ? "Edit planned expense" : "New planned expense"}</span>
        <button onClick={onCancel} aria-label="Cancel" style={{ color: colors.textMuted }}><X size={16} /></button>
      </div>

      <label className="text-xs uppercase tracking-wide block mb-1.5" style={{ color: colors.textMuted, letterSpacing: "0.08em" }}>Name</label>
      <input value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Mom's birthday" className="w-full rounded-lg px-3 py-2 text-sm mb-3 focus:outline-none" style={{ background: colors.bg, border: `1px solid ${colors.border}`, color: colors.text }} />

      <label className="text-xs uppercase tracking-wide block mb-1.5" style={{ color: colors.textMuted, letterSpacing: "0.08em" }}>Category</label>
      <div className="relative mb-3">
        <select value={category} onChange={(e) => setCategory(e.target.value)} className="w-full appearance-none rounded-lg px-3 py-2 text-sm focus:outline-none" style={{ background: colors.bg, border: `1px solid ${colors.border}`, color: colors.text }}>
          {CATEGORY_OPTIONS.map((c) => <option key={c} value={c}>{c}</option>)}
        </select>
        <ChevronDown size={16} className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" style={{ color: colors.textMuted }} />
      </div>

      <div className="flex gap-2 mb-3">
        <div className="flex-1">
          <label className="text-xs uppercase tracking-wide block mb-1.5" style={{ color: colors.textMuted, letterSpacing: "0.08em" }}>Target amount</label>
          <div className="relative">
            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm" style={{ color: colors.textMuted, fontFamily: fontMono }}>$</span>
            <input type="number" inputMode="decimal" value={targetAmount} onChange={(e) => setTargetAmount(e.target.value)} placeholder="0.00" className="w-full rounded-lg pl-6 pr-2 py-2 text-sm focus:outline-none" style={{ background: colors.bg, border: `1px solid ${colors.border}`, color: colors.text, fontFamily: fontMono }} />
          </div>
        </div>
        <div className="flex-1">
          <label className="text-xs uppercase tracking-wide block mb-1.5" style={{ color: colors.textMuted, letterSpacing: "0.08em" }}>Already saved</label>
          <div className="relative">
            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm" style={{ color: colors.textMuted, fontFamily: fontMono }}>$</span>
            <input type="number" inputMode="decimal" value={amountSaved} onChange={(e) => setAmountSaved(e.target.value)} placeholder="0.00" className="w-full rounded-lg pl-6 pr-2 py-2 text-sm focus:outline-none" style={{ background: colors.bg, border: `1px solid ${colors.border}`, color: colors.text, fontFamily: fontMono }} />
          </div>
        </div>
      </div>

      <label className="text-xs uppercase tracking-wide block mb-1.5" style={{ color: colors.textMuted, letterSpacing: "0.08em" }}>Target date</label>
      <input type="date" value={targetDate} onChange={(e) => setTargetDate(e.target.value)} className="w-full rounded-lg px-3 py-2 text-sm mb-3 focus:outline-none" style={{ background: colors.bg, border: `1px solid ${colors.border}`, color: colors.text, colorScheme: "dark" }} />

      <div className="flex rounded-lg p-1 mb-3" style={{ background: colors.bg, border: `1px solid ${colors.border}` }}>
        {[{ key: "one_time", label: "One-time" }, { key: "annual", label: "Annual (e.g. birthday)" }].map((opt) => (
          <button key={opt.key} type="button" onClick={() => setRecurrenceType(opt.key)} className="flex-1 rounded-md py-1.5 text-xs font-medium" style={{ background: recurrenceType === opt.key ? colors.accent : "transparent", color: recurrenceType === opt.key ? colors.bg : colors.textMuted }}>
            {opt.label}
          </button>
        ))}
      </div>

      <label className="text-xs uppercase tracking-wide block mb-1.5" style={{ color: colors.textMuted, letterSpacing: "0.08em" }}>Contribute</label>
      <div className="relative mb-3">
        <select value={contributionFrequency} onChange={(e) => setContributionFrequency(e.target.value)} className="w-full appearance-none rounded-lg px-3 py-2 text-sm focus:outline-none" style={{ background: colors.bg, border: `1px solid ${colors.border}`, color: colors.text }}>
          {CONTRIBUTION_FREQUENCIES.map((f) => <option key={f.value} value={f.value}>{f.label}</option>)}
        </select>
        <ChevronDown size={16} className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" style={{ color: colors.textMuted }} />
      </div>

      {accounts.length > 0 && (
        <>
          <label className="text-xs uppercase tracking-wide block mb-1.5" style={{ color: colors.textMuted, letterSpacing: "0.08em" }}>Where savings accumulate <span style={{ opacity: 0.6, textTransform: "none" }}>(optional)</span></label>
          <div className="relative mb-3">
            <select value={linkedAccountId} onChange={(e) => setLinkedAccountId(e.target.value)} className="w-full appearance-none rounded-lg px-3 py-2 text-sm focus:outline-none" style={{ background: colors.bg, border: `1px solid ${colors.border}`, color: colors.text }}>
              <option value="">None</option>
              {accounts.map((a) => <option key={a.accountId} value={a.accountId}>{a.name}</option>)}
            </select>
            <ChevronDown size={16} className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" style={{ color: colors.textMuted }} />
          </div>
        </>
      )}

      <label className="text-xs uppercase tracking-wide block mb-1.5" style={{ color: colors.textMuted, letterSpacing: "0.08em" }}>Notes <span style={{ opacity: 0.6, textTransform: "none" }}>(optional)</span></label>
      <textarea value={notes} onChange={(e) => setNotes(e.target.value.slice(0, 250))} rows={2} className="w-full rounded-lg px-3 py-2 text-sm mb-4 focus:outline-none resize-none" style={{ background: colors.bg, border: `1px solid ${colors.border}`, color: colors.text }} />

      <button
        type="button"
        disabled={!canSave || saving}
        onClick={() => onSave(buildPayload())}
        className="w-full rounded-lg py-2.5 text-sm font-medium"
        style={{ background: canSave ? colors.accent : colors.surface, color: canSave ? colors.bg : colors.textMuted, opacity: saving ? 0.6 : 1 }}
      >
        {saving ? "Saving…" : isEditing ? "Save changes" : "Create"}
      </button>
    </div>
  );
}

export default function PlannedExpensesPage() {
  const [items, setItems] = useState(null);
  const [accounts, setAccounts] = useState([]);
  const [error, setError] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  const [saving, setSaving] = useState(false);

  function refresh() {
    Promise.all([plannedExpensesApi.list(), accountsApi.list()])
      .then(([list, accts]) => {
        setItems(list);
        setAccounts(accts);
      })
      .catch(() => setError("Couldn't load your planned expenses."));
  }

  useEffect(refresh, []);

  const totalSuggestedMonthly = (items || []).reduce((sum, i) => {
    const monthly = i.contributionFrequency === "weekly" ? i.suggestedContribution * 4.33 : i.contributionFrequency === "biweekly" ? i.suggestedContribution * 2.17 : i.suggestedContribution;
    return sum + monthly;
  }, 0);

  async function saveItem(payload) {
    setSaving(true);
    setError(null);
    try {
      if (editingItem) {
        await plannedExpensesApi.update(editingItem.plannedExpenseId, payload);
      } else {
        await plannedExpensesApi.create(payload);
      }
      setShowForm(false);
      setEditingItem(null);
      refresh();
    } catch (err) {
      setError(err.message || "Couldn't save that planned expense.");
    } finally {
      setSaving(false);
    }
  }

  async function deleteItem(item) {
    try {
      await plannedExpensesApi.remove(item.plannedExpenseId);
      refresh();
    } catch (err) {
      setError(err.message || "Couldn't delete that.");
    }
  }

  return (
    <div className="min-h-screen pb-10" style={{ background: colors.bg, fontFamily: fontBody }}>
      <PageHeader title="Planned expenses" />

      <div className="px-5 pt-6 max-w-md mx-auto">
        {error && <p className="text-sm mb-4" style={{ color: colors.alert }}>{error}</p>}

        {items && items.length > 0 && (
          <div className="rounded-2xl p-4 mb-5 relative overflow-hidden" style={{ background: colors.surface, border: `1px solid ${colors.border}` }}>
            <PerfEdge />
            <div className="flex items-center mb-1">
              <p className="text-xs uppercase tracking-wide" style={{ color: colors.textMuted, letterSpacing: "0.08em" }}>Suggested monthly total</p>
              <InfoBubble text="All your suggested contributions, normalized to a monthly figure, added together — this is roughly what to set aside each month across everything you're planning for." />
            </div>
            <p style={{ fontFamily: fontMono, fontSize: 22, color: colors.accentLight }}>{formatMoney(totalSuggestedMonthly)}</p>
          </div>
        )}

        {showForm ? (
          <PlannedExpenseForm
            key={editingItem?.plannedExpenseId ?? "new"}
            accounts={accounts}
            initial={editingItem}
            saving={saving}
            onCancel={() => { setShowForm(false); setEditingItem(null); }}
            onSave={saveItem}
          />
        ) : (
          <button type="button" onClick={() => setShowForm(true)} className="w-full rounded-2xl py-3 mb-5 text-sm font-medium flex items-center justify-center gap-2" style={{ border: `1px dashed ${colors.borderStrong}`, color: colors.textMuted }}>
            <Plus size={16} />
            Add a planned expense
          </button>
        )}

        {items === null && !error && <p className="text-sm" style={{ color: colors.textMuted }}>Loading…</p>}
        {items !== null && items.length === 0 && <p className="text-sm" style={{ color: colors.textMuted }}>Nothing planned yet.</p>}
        {(items || []).map((item) => (
          <PlannedExpenseCard
            key={item.plannedExpenseId}
            item={item}
            onEdit={(i) => { setEditingItem(i); setShowForm(true); }}
            onDelete={deleteItem}
          />
        ))}
      </div>
    </div>
  );
}
