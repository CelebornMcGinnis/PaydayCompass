import React, { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, Pencil, Plus, Trash2, Check, ArrowDownLeft, ArrowUpRight, UserX } from "lucide-react";
import { paydayApi, accountsApi, budgetsApi } from "../lib/apiClient";
import { getCurrentUserEmail } from "../lib/cognito";
import { colors, fontDisplay, fontBody, fontMono, formatMoney } from "../lib/theme";
import PageHeader from "../components/PageHeader";

const DEFAULT_CATEGORY_OPTIONS = ["Groceries", "Dining", "Utilities", "Transportation", "Household", "Uncategorized"];

function draftStorageKey() {
  return `payday-unpredicted-draft:${getCurrentUserEmail() || "anonymous"}`;
}

function uid() {
  return Math.random().toString(36).slice(2, 9);
}

function ExpenseRow({ item, amount, onAmountChange }) {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(String(amount));

  function commit() {
    const n = parseFloat(draft);
    if (!isNaN(n) && n > 0) onAmountChange(n);
    setEditing(false);
  }

  return (
    <div className="flex items-center justify-between py-3" style={{ borderBottom: `1px solid ${colors.border}` }}>
      <div className="flex items-center gap-3 min-w-0">
        <div className="flex items-center justify-center rounded-lg shrink-0" style={{ width: 32, height: 32, background: colors.surfaceRaised, color: colors.alert }}>
          <ArrowUpRight size={15} strokeWidth={2} />
        </div>
        <div className="min-w-0">
          <p className="text-sm truncate" style={{ color: colors.text }}>{item.description}</p>
          <p className="text-xs truncate" style={{ color: colors.textMuted }}>
            {item.category} · due {item.dueDate} ·{" "}
            <span style={{ color: item.externalBankAccountName ? colors.textMuted : colors.alert }}>
              {item.externalBankAccountName || "Unassigned account"}
            </span>
          </p>
        </div>
      </div>
      {editing ? (
        <div className="flex items-center gap-1.5 shrink-0 pl-2">
          <span className="text-sm" style={{ color: colors.textMuted, fontFamily: fontMono }}>$</span>
          <input
            autoFocus
            type="number"
            inputMode="decimal"
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            onBlur={commit}
            onKeyDown={(e) => e.key === "Enter" && commit()}
            className="w-20 rounded-md px-2 py-1 text-sm text-right focus:outline-none"
            style={{ background: colors.bg, border: `1px solid ${colors.accentLight}`, color: colors.text, fontFamily: fontMono }}
          />
        </div>
      ) : (
        <button type="button" onClick={() => { setDraft(String(amount)); setEditing(true); }} className="flex items-center gap-1.5 shrink-0 pl-2">
          <span style={{ fontFamily: fontMono, fontSize: 14, color: colors.text }}>{formatMoney(amount)}</span>
          <Pencil size={13} style={{ color: colors.textMuted }} />
        </button>
      )}
    </div>
  );
}

export default function PaydayPage() {
  const navigate = useNavigate();
  const [data, setData] = useState(null);
  const [accounts, setAccounts] = useState([]);
  const [categoryOptions, setCategoryOptions] = useState(DEFAULT_CATEGORY_OPTIONS);
  const [expenseAmounts, setExpenseAmounts] = useState({});
  // Restored from localStorage so navigating away and back (or an
  // accidental reload) doesn't lose unsubmitted unpredicted amounts -
  // these should only ever clear on a successful submit, never just from
  // leaving the page.
  const [unpredicted, setUnpredicted] = useState(() => {
    try {
      const raw = localStorage.getItem(draftStorageKey());
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  });
  const [selectedRecipients, setSelectedRecipients] = useState([]);
  const [recipientMessages, setRecipientMessages] = useState({});
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    Promise.all([paydayApi.upcoming(), accountsApi.list(), budgetsApi.list()])
      .then(([d, accts, budgets]) => {
        setData(d);
        setAccounts(accts);
        setExpenseAmounts(Object.fromEntries(d.upcomingExpenses.map((e) => [e.recurringId, e.estimatedAmount])));
        // Real categories the user has actually created budgets for,
        // merged with the defaults - previously this was a hardcoded
        // list unrelated to what the user set up in Budgets at all.
        const realCategories = budgets.map((b) => b.category);
        setCategoryOptions([...new Set([...DEFAULT_CATEGORY_OPTIONS, ...realCategories])]);
      })
      .catch(() => setError("Couldn't load your upcoming payday."));
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem(draftStorageKey(), JSON.stringify(unpredicted));
    } catch {
      // best-effort - if storage is unavailable, the draft just won't
      // persist across navigation, but the page still works
    }
  }, [unpredicted]);

  const totalIncomeNet = (data?.income || []).reduce((s, i) => s + i.netAmount, 0);
  const beforePaydayIds = useMemo(() => new Set((data?.upcomingExpenses || []).filter((e) => !e.isAfterPayday).map((e) => e.recurringId)), [data]);
  const totalExpenses = useMemo(
    () => Object.entries(expenseAmounts).reduce((s, [id, v]) => (beforePaydayIds.has(id) ? s + v : s), 0),
    [expenseAmounts, beforePaydayIds]
  );
  const totalUnpredicted = useMemo(() => unpredicted.reduce((s, r) => s + (parseFloat(r.amount) || 0), 0), [unpredicted]);
  const leftover = totalIncomeNet - totalExpenses - totalUnpredicted;

  function addUnpredicted() {
    setUnpredicted((r) => [...r, { id: uid(), description: "", amount: "", category: "Uncategorized", accountId: accounts[0]?.accountId || "" }]);
  }
  function updateUnpredicted(id, next) {
    setUnpredicted((r) => r.map((row) => (row.id === id ? next : row)));
  }
  function removeUnpredicted(id) {
    setUnpredicted((r) => r.filter((row) => row.id !== id));
  }
  function toggleRecipient(userId) {
    setSelectedRecipients((ids) => {
      if (ids.includes(userId)) return ids.filter((i) => i !== userId);
      setRecipientMessages((m) => ({ ...m, [userId]: m[userId] || { amount: "", message: "" } }));
      return [...ids, userId];
    });
  }
  function updateRecipientMessage(userId, field, value) {
    setRecipientMessages((m) => ({ ...m, [userId]: { ...m[userId], [field]: value } }));
  }

  async function handleSubmit() {
    if (!data) return;
    setSubmitting(true);
    setError(null);
    try {
      await paydayApi.submit({
        recurringAdjustments: data.upcomingExpenses
          .filter((e) => !e.isAfterPayday)
          .map((e) => ({
            recurringId: e.recurringId,
            accountId: e.accountId,
            amount: expenseAmounts[e.recurringId],
          })),
        additionalTransactions: unpredicted
          .filter((r) => parseFloat(r.amount) > 0 && r.accountId)
          .map((r) => ({ accountId: r.accountId, amount: parseFloat(r.amount), category: r.category, description: r.description, direction: "debit" })),
        peerNotifications: selectedRecipients.map((userId) => ({
          recipientUserId: userId,
          amount: parseFloat(recipientMessages[userId]?.amount) || 0,
          dueDate: data.nextPayday,
          message: recipientMessages[userId]?.message || "",
        })),
      });
      setSubmitted(true);
      try {
        localStorage.removeItem(draftStorageKey());
      } catch {
        // non-fatal - worst case a stale draft reappears next visit
      }
      setTimeout(() => navigate("/"), 1500);
    } catch (err) {
      setError(err.message || "Couldn't submit - try again.");
    } finally {
      setSubmitting(false);
    }
  }

  if (error && !data) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: colors.bg }}>
        <p className="text-sm" style={{ color: colors.alert }}>{error}</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen pb-28" style={{ background: colors.bg, fontFamily: fontBody }}>
      <PageHeader title="Payday" subtitle={data ? `due ${data.nextPayday}` : undefined} />

      {!data ? (
        <p className="text-sm px-5 pt-6" style={{ color: colors.textMuted }}>Loading…</p>
      ) : (
        <div className="px-5 pt-6 max-w-md mx-auto">
          <div className="rounded-2xl p-4 mb-5" style={{ background: colors.surface, border: `1px solid ${colors.border}` }}>
            {data.income.map((inc) => (
              <div key={inc.recurringId} className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="flex items-center justify-center rounded-lg" style={{ width: 32, height: 32, background: colors.surfaceRaised, color: colors.positive }}>
                    <ArrowDownLeft size={15} strokeWidth={2} />
                  </div>
                  <div>
                    <p className="text-sm" style={{ color: colors.text }}>{inc.description}</p>
                    <p className="text-xs" style={{ color: colors.textMuted }}>
                      arriving {inc.dueDate}
                      {inc.grossAmount != null && ` · gross ${formatMoney(inc.grossAmount)}`}
                    </p>
                  </div>
                </div>
                <span style={{ fontFamily: fontMono, fontSize: 15, color: colors.positive }}>+{formatMoney(inc.netAmount)}</span>
              </div>
            ))}
          </div>

          <h3 style={{ fontFamily: fontDisplay, color: colors.text, fontSize: 15, fontWeight: 600 }} className="mb-2 px-1">Money to move out</h3>
          <div className="rounded-2xl px-4 mb-5" style={{ background: colors.surface, border: `1px solid ${colors.border}` }}>
            {data.upcomingExpenses.filter((e) => !e.isAfterPayday).length === 0 ? (
              <p className="text-sm py-4 text-center" style={{ color: colors.textMuted }}>Nothing due before payday.</p>
            ) : (
              data.upcomingExpenses
                .filter((e) => !e.isAfterPayday)
                .map((e) => (
                  <ExpenseRow
                    key={e.recurringId}
                    item={e}
                    amount={expenseAmounts[e.recurringId]}
                    onAmountChange={(n) => setExpenseAmounts((a) => ({ ...a, [e.recurringId]: n }))}
                  />
                ))
            )}
          </div>

          {data.upcomingExpenses.some((e) => e.isAfterPayday) && (
            <>
              <h3 style={{ fontFamily: fontDisplay, color: colors.text, fontSize: 15, fontWeight: 600 }} className="mb-2 px-1">
                Due within 5 days after <span className="text-xs font-normal" style={{ color: colors.textMuted }}>(not this payday's money, but coming soon)</span>
              </h3>
              <div className="rounded-2xl px-4 mb-5" style={{ background: colors.surface, border: `1px dashed ${colors.borderStrong}` }}>
                {data.upcomingExpenses
                  .filter((e) => e.isAfterPayday)
                  .map((e) => (
                    <ExpenseRow
                      key={e.recurringId}
                      item={e}
                      amount={expenseAmounts[e.recurringId]}
                      onAmountChange={(n) => setExpenseAmounts((a) => ({ ...a, [e.recurringId]: n }))}
                    />
                  ))}
              </div>
            </>
          )}

          {data.aggregateByExternalBankAccount?.length > 0 && (
            <>
              <h3 style={{ fontFamily: fontDisplay, color: colors.text, fontSize: 15, fontWeight: 600 }} className="mb-2 px-1">By bank account</h3>
              <div className="rounded-2xl px-4 mb-5" style={{ background: colors.surface, border: `1px solid ${colors.border}` }}>
                {data.aggregateByExternalBankAccount.map((row) => (
                  <div key={row.bankAccountName} className="flex items-center justify-between py-2.5" style={{ borderBottom: `1px solid ${colors.border}` }}>
                    <span className="text-sm" style={{ color: row.bankAccountName === "Unassigned" ? colors.alert : colors.text }}>{row.bankAccountName}</span>
                    <span style={{ fontFamily: fontMono, fontSize: 14, color: colors.text }}>{formatMoney(row.total)}</span>
                  </div>
                ))}
              </div>
            </>
          )}

          <h3 style={{ fontFamily: fontDisplay, color: colors.text, fontSize: 15, fontWeight: 600 }} className="mb-2 px-1">
            Unpredicted amounts <span className="text-xs font-normal" style={{ color: colors.textMuted }}>(optional)</span>
          </h3>
          {unpredicted.map((row) => (
            <div key={row.id} className="rounded-xl p-3 mb-2.5" style={{ background: colors.surfaceRaised, border: `1px solid ${colors.border}` }}>
              <input
                value={row.description}
                onChange={(e) => updateUnpredicted(row.id, { ...row, description: e.target.value })}
                placeholder="Description"
                className="w-full rounded-lg px-2.5 py-2 text-sm mb-2 focus:outline-none"
                style={{ background: colors.bg, border: `1px solid ${colors.border}`, color: colors.text }}
              />
              <div className="flex gap-2 mb-2">
                <input
                  type="number"
                  inputMode="decimal"
                  value={row.amount}
                  onChange={(e) => updateUnpredicted(row.id, { ...row, amount: e.target.value })}
                  placeholder="0.00"
                  className="flex-1 rounded-lg px-3 py-2 text-sm focus:outline-none"
                  style={{ background: colors.bg, border: `1px solid ${colors.border}`, color: colors.text, fontFamily: fontMono }}
                />
                <select
                  value={row.category}
                  onChange={(e) => updateUnpredicted(row.id, { ...row, category: e.target.value })}
                  className="flex-1 rounded-lg px-2 py-2 text-sm focus:outline-none"
                  style={{ background: colors.bg, border: `1px solid ${colors.border}`, color: colors.text }}
                >
                  {categoryOptions.map((c) => <option key={c} value={c}>{c}</option>)}
                </select>
                <button type="button" onClick={() => removeUnpredicted(row.id)} aria-label="Remove" style={{ color: colors.alert }}>
                  <Trash2 size={16} />
                </button>
              </div>
              <select
                value={row.accountId}
                onChange={(e) => updateUnpredicted(row.id, { ...row, accountId: e.target.value })}
                className="w-full rounded-lg px-2.5 py-2 text-sm focus:outline-none"
                style={{ background: colors.bg, border: `1px solid ${colors.border}`, color: colors.text }}
              >
                {accounts.map((a) => <option key={a.accountId} value={a.accountId}>{a.name}</option>)}
              </select>
            </div>
          ))}
          <button type="button" onClick={addUnpredicted} className="w-full rounded-xl py-2.5 mb-5 text-sm font-medium flex items-center justify-center gap-2" style={{ border: `1px dashed ${colors.borderStrong}`, color: colors.textMuted }}>
            <Plus size={15} /> Add unpredicted amount
          </button>

          <div className="rounded-2xl p-4 flex items-center justify-between mb-5" style={{ background: colors.surfaceRaised, border: `1px solid ${colors.border}` }}>
            <span className="text-xs" style={{ color: colors.textMuted }}>Left over after this payday</span>
            <span style={{ fontFamily: fontMono, fontSize: 17, color: leftover >= 0 ? colors.positive : colors.alert }}>{formatMoney(leftover)}</span>
          </div>

          {data.shareableRecipients?.length > 0 && (
            <>
              <h3 style={{ fontFamily: fontDisplay, color: colors.text, fontSize: 15, fontWeight: 600 }} className="mb-2 px-1">Let someone know</h3>
              <div className="rounded-2xl px-4 mb-5" style={{ background: colors.surface, border: `1px solid ${colors.border}` }}>
                {data.shareableRecipients.map((r) => {
                  const eligible = r.agreementStatus === "accepted";
                  const selected = selectedRecipients.includes(r.userId);
                  return (
                    <div key={r.userId}>
                      <div className="flex items-center justify-between py-2.5" style={{ borderBottom: `1px solid ${colors.border}` }}>
                        <div className="flex items-center gap-2.5 min-w-0">
                          <button
                            type="button"
                            disabled={!eligible}
                            onClick={() => toggleRecipient(r.userId)}
                            className="flex items-center justify-center rounded-full shrink-0"
                            style={{ width: 18, height: 18, border: `1.5px solid ${selected ? colors.accentLight : colors.borderStrong}`, background: selected ? colors.accentLight : "transparent", opacity: eligible ? 1 : 0.4 }}
                          >
                            {selected && <Check size={11} style={{ color: colors.bg }} />}
                          </button>
                          <span className="text-sm truncate" style={{ color: eligible ? colors.text : colors.textMuted }}>{r.email}</span>
                        </div>
                        {!eligible && (
                          <span className="flex items-center gap-1 text-xs shrink-0 pl-2" style={{ color: colors.textMuted }}>
                            <UserX size={12} /> {r.agreementStatus === "pending" ? "invite pending" : "not invited"}
                          </span>
                        )}
                      </div>
                      {selected && (
                        <div className="pb-3 flex gap-2">
                          <input
                            type="number"
                            inputMode="decimal"
                            value={recipientMessages[r.userId]?.amount || ""}
                            onChange={(e) => updateRecipientMessage(r.userId, "amount", e.target.value)}
                            placeholder="$0.00"
                            style={{ width: 90, background: colors.surfaceRaised, border: `1px solid ${colors.border}`, color: colors.text, fontFamily: fontMono }}
                            className="rounded-lg px-2 py-1.5 text-sm focus:outline-none"
                          />
                          <input
                            value={recipientMessages[r.userId]?.message || ""}
                            onChange={(e) => updateRecipientMessage(r.userId, "message", e.target.value)}
                            placeholder="Message"
                            className="flex-1 rounded-lg px-2.5 py-1.5 text-sm focus:outline-none"
                            style={{ background: colors.surfaceRaised, border: `1px solid ${colors.border}`, color: colors.text }}
                          />
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </>
          )}

          {error && <p className="text-sm mb-4" style={{ color: colors.alert }}>{error}</p>}
        </div>
      )}

      <div className="fixed bottom-0 left-0 right-0 px-5 py-4 z-30" style={{ background: colors.surface, borderTop: `1px solid ${colors.border}` }}>
        <div className="max-w-md mx-auto">
          <button
            type="button"
            onClick={handleSubmit}
            disabled={!data || submitting}
            className="w-full rounded-xl py-3 text-sm font-medium flex items-center justify-center gap-2"
            style={{ background: colors.accent, color: colors.bg, opacity: submitting ? 0.6 : 1 }}
          >
            {submitted ? (<><Check size={16} /> Submitted</>) : submitting ? "Submitting…" : "I've moved the money \u2014 submit"}
          </button>
        </div>
      </div>
    </div>
  );
}
