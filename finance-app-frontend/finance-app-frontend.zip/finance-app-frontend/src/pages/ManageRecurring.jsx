import React, { useEffect, useState } from "react";
import { ArrowLeft, Plus, ChevronRight, Bell, BellOff, ChevronDown } from "lucide-react";
import { accountsApi, externalBankAccountsApi, recurringApi } from "../lib/apiClient";
import { colors, fontDisplay, fontBody, fontMono, formatMoney } from "../lib/theme";
import PageHeader from "../components/PageHeader";

const CATEGORY_OPTIONS = ["Groceries", "Dining", "Utilities", "Transportation", "Household", "Entertainment", "Health", "Rent/Mortgage"];
const FREQUENCIES = [
  { key: "weekly", label: "Weekly" },
  { key: "biweekly", label: "Every 2 weeks" },
  { key: "semimonthly", label: "Twice a month (fixed days)" },
  { key: "monthly", label: "Monthly" },
  { key: "annual", label: "Annually" },
];

function PerfEdge() {
  return <div className="absolute top-0 left-0 right-0 h-px" style={{ backgroundImage: `repeating-linear-gradient(90deg, ${colors.borderStrong} 0, ${colors.borderStrong} 5px, transparent 5px, transparent 11px)` }} />;
}

function FieldLabel({ children }) {
  return (
    <label className="text-xs uppercase tracking-wide block mb-1.5" style={{ color: colors.textMuted, letterSpacing: "0.08em" }}>
      {children}
    </label>
  );
}

function Select({ value, onChange, options }) {
  return (
    <div className="relative">
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full appearance-none rounded-lg px-3 py-2.5 text-sm focus:outline-none"
        style={{ background: colors.bg, border: `1px solid ${colors.border}`, color: colors.text }}
      >
        {options.map((opt) => (
          <option key={opt.value ?? opt} value={opt.value ?? opt}>{opt.label ?? opt}</option>
        ))}
      </select>
      <ChevronDown size={16} className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" style={{ color: colors.textMuted }} />
    </div>
  );
}

function RecurringListRow({ item, externalAccountsById, onSelect }) {
  const bankName = item.externalBankAccountId ? externalAccountsById[item.externalBankAccountId] : null;
  return (
    <button type="button" onClick={onSelect} className="w-full flex items-center justify-between py-3 text-left" style={{ borderBottom: `1px solid ${colors.border}` }}>
      <div className="min-w-0">
        <p className="text-sm truncate" style={{ color: colors.text }}>{item.description || "(untitled)"}</p>
        <p className="text-xs truncate" style={{ color: colors.textMuted }}>
          {FREQUENCIES.find((f) => f.key === item.frequency)?.label || item.frequency}
          {!item.isIncome && (bankName ? ` · ${bankName}` : " · Unassigned account")}
          {item.sharedFromUserId && " · shared"}
        </p>
      </div>
      <div className="flex items-center gap-2 shrink-0 pl-3">
        {item.notificationsEnabled ? <Bell size={13} style={{ color: colors.textMuted }} /> : <BellOff size={13} style={{ color: colors.textMuted, opacity: 0.5 }} />}
        <span style={{ fontFamily: fontMono, fontSize: 14, color: item.isIncome ? colors.positive : colors.text }}>
          {item.isIncome ? "+" : ""}{formatMoney(item.estimatedAmount)}
        </span>
        <ChevronRight size={15} style={{ color: colors.textMuted }} />
      </div>
    </button>
  );
}

function RecurringForm({ accounts, externalAccounts, initial, onCancel, onSave, onDelete, saving }) {
  const isEditing = !!initial;
  const [isIncome, setIsIncome] = useState(initial?.isIncome ?? false);
  const [description, setDescription] = useState(initial?.description ?? "");
  const [category, setCategory] = useState(initial?.category ?? CATEGORY_OPTIONS[0]);
  const [addingCategory, setAddingCategory] = useState(false);
  const [customCategory, setCustomCategory] = useState("");
  const [accountId, setAccountId] = useState(initial?.accountId ?? accounts[0]?.accountId ?? "");
  const [amount, setAmount] = useState(initial?.estimatedAmount != null ? String(initial.estimatedAmount) : "");
  const [grossAmount, setGrossAmount] = useState(initial?.grossAmount != null ? String(initial.grossAmount) : "");
  const [frequency, setFrequency] = useState(initial?.frequency ?? "monthly");
  const [externalBankAccountId, setExternalBankAccountId] = useState(initial?.externalBankAccountId ?? "");
  const [notificationsEnabled, setNotificationsEnabled] = useState(initial?.notificationsEnabled ?? true);
  const [startDate, setStartDate] = useState(initial?.nextDueDate ?? new Date().toISOString().slice(0, 10));
  const [showBackfillConfirm, setShowBackfillConfirm] = useState(false);

  const effectiveCategory = addingCategory ? customCategory.trim() : category;
  const canSave = description.trim() && parseFloat(amount) > 0 && accountId && (isIncome || effectiveCategory);

  function buildPayload() {
    return {
      accountId,
      isIncome,
      description: description.trim(),
      category: isIncome ? undefined : effectiveCategory,
      estimatedAmount: parseFloat(amount),
      grossAmount: isIncome && grossAmount ? parseFloat(grossAmount) : undefined,
      frequency,
      externalBankAccountId: isIncome ? undefined : externalBankAccountId || null,
      notificationsEnabled,
      startDate: isEditing ? undefined : startDate,
      nextDueDate: isEditing ? startDate : undefined,
    };
  }

  return (
    <div className="max-w-md mx-auto px-5 pt-6 pb-10">
      <div className="flex rounded-xl p-1 mb-5" style={{ background: colors.surfaceRaised, border: `1px solid ${colors.border}` }}>
        {[{ key: false, label: "Expense" }, { key: true, label: "Income" }].map((opt) => (
          <button
            key={String(opt.key)}
            type="button"
            disabled={isEditing}
            onClick={() => setIsIncome(opt.key)}
            className="flex-1 rounded-lg py-2 text-sm font-medium transition-colors"
            style={{
              background: isIncome === opt.key ? (opt.key ? colors.accent : colors.alert) : "transparent",
              color: isIncome === opt.key ? colors.bg : colors.textMuted,
              opacity: isEditing && isIncome !== opt.key ? 0.4 : 1,
            }}
          >
            {opt.label}
          </button>
        ))}
      </div>

      <div className="mb-4">
        <FieldLabel>Description</FieldLabel>
        <input
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          placeholder={isIncome ? "e.g. Payroll deposit" : "e.g. Electric bill"}
          className="w-full rounded-lg px-3 py-2.5 text-sm focus:outline-none"
          style={{ background: colors.bg, border: `1px solid ${colors.border}`, color: colors.text }}
        />
      </div>

      <div className="mb-4">
        <FieldLabel>Account</FieldLabel>
        <Select value={accountId} onChange={setAccountId} options={accounts.map((a) => ({ value: a.accountId, label: a.name }))} />
      </div>

      {!isIncome && (
        <div className="mb-4">
          <FieldLabel>Category</FieldLabel>
          {addingCategory ? (
            <div className="flex gap-2">
              <input
                autoFocus
                value={customCategory}
                onChange={(e) => setCustomCategory(e.target.value)}
                placeholder="New category name"
                className="flex-1 rounded-lg px-3 py-2.5 text-sm focus:outline-none"
                style={{ background: colors.bg, border: `1px solid ${colors.border}`, color: colors.text }}
              />
              <button type="button" onClick={() => { setAddingCategory(false); setCustomCategory(""); }} className="rounded-lg px-3 text-xs" style={{ border: `1px solid ${colors.border}`, color: colors.textMuted }}>Cancel</button>
            </div>
          ) : (
            <Select
              value={category}
              onChange={(v) => { if (v === "__new__") setAddingCategory(true); else setCategory(v); }}
              options={[...CATEGORY_OPTIONS, { value: "__new__", label: "+ Add a new category…" }]}
            />
          )}
        </div>
      )}

      <div className="mb-4">
        <FieldLabel>{isIncome ? "Net amount" : "Amount"}</FieldLabel>
        <div className="relative">
          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm" style={{ color: colors.textMuted, fontFamily: fontMono }}>$</span>
          <input type="number" inputMode="decimal" value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="0.00" className="w-full rounded-lg pl-6 pr-3 py-2.5 text-sm focus:outline-none" style={{ background: colors.bg, border: `1px solid ${colors.border}`, color: colors.text, fontFamily: fontMono }} />
        </div>
      </div>

      {isIncome && (
        <div className="mb-4">
          <FieldLabel>Gross amount <span style={{ opacity: 0.6, textTransform: "none" }}>(optional, reference only)</span></FieldLabel>
          <div className="relative">
            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm" style={{ color: colors.textMuted, fontFamily: fontMono }}>$</span>
            <input type="number" inputMode="decimal" value={grossAmount} onChange={(e) => setGrossAmount(e.target.value)} placeholder="0.00" className="w-full rounded-lg pl-6 pr-3 py-2.5 text-sm focus:outline-none" style={{ background: colors.bg, border: `1px solid ${colors.border}`, color: colors.text, fontFamily: fontMono }} />
          </div>
        </div>
      )}

      {!isIncome && (
        <div className="mb-4">
          <FieldLabel>External bank account <span style={{ opacity: 0.6, textTransform: "none" }}>(optional)</span></FieldLabel>
          <Select
            value={externalBankAccountId}
            onChange={setExternalBankAccountId}
            options={[{ value: "", label: "Unassigned" }, ...externalAccounts.map((b) => ({ value: b.externalBankAccountId, label: b.name }))]}
          />
        </div>
      )}

      <div className="mb-4">
        <FieldLabel>Frequency</FieldLabel>
        <Select value={frequency} onChange={setFrequency} options={FREQUENCIES.map((f) => ({ value: f.key, label: f.label }))} />
      </div>

      <div className="mb-5">
        <FieldLabel>{isEditing ? "Next due date" : "Starts"}</FieldLabel>
        <input type="date" value={startDate} min={new Date(Date.now() - 365 * 86400000).toISOString().slice(0, 10)} onChange={(e) => setStartDate(e.target.value)} className="w-full rounded-lg px-3 py-2.5 text-sm focus:outline-none" style={{ background: colors.bg, border: `1px solid ${colors.border}`, color: colors.text, colorScheme: "dark" }} />
      </div>

      <div className="flex items-center justify-between rounded-xl px-4 py-3 mb-6" style={{ background: colors.surfaceRaised, border: `1px solid ${colors.border}` }}>
        <div className="flex items-center gap-2">
          {notificationsEnabled ? <Bell size={15} style={{ color: colors.accentLight }} /> : <BellOff size={15} style={{ color: colors.textMuted }} />}
          <span className="text-sm" style={{ color: colors.text }}>Budget alerts for this item</span>
        </div>
        <button type="button" onClick={() => setNotificationsEnabled((v) => !v)} className="relative rounded-full transition-colors" style={{ width: 40, height: 22, background: notificationsEnabled ? colors.accent : colors.border }} aria-label="Toggle notifications">
          <span className="absolute rounded-full transition-transform" style={{ width: 18, height: 18, top: 2, left: 2, background: colors.text, transform: notificationsEnabled ? "translateX(18px)" : "translateX(0)" }} />
        </button>
      </div>

      <div className="flex gap-3 mb-3">
        <button type="button" onClick={onCancel} className="flex-1 rounded-xl py-3 text-sm font-medium" style={{ border: `1px solid ${colors.border}`, color: colors.textMuted }}>Cancel</button>
        <button
          type="button"
          disabled={!canSave || saving}
          onClick={() => {
            const isPastDate = !isEditing && startDate < new Date().toISOString().slice(0, 10);
            if (isPastDate) setShowBackfillConfirm(true);
            else onSave(buildPayload());
          }}
          className="flex-1 rounded-xl py-3 text-sm font-medium"
          style={{ background: canSave ? colors.accent : colors.surfaceRaised, color: canSave ? colors.bg : colors.textMuted, opacity: saving ? 0.6 : 1 }}
        >
          {saving ? "Saving…" : isEditing ? "Save changes" : "Create"}
        </button>
      </div>

      {showBackfillConfirm && (
        <div className="fixed inset-0 flex items-center justify-center px-6 z-50" style={{ background: "rgba(15,27,45,0.8)" }}>
          <div className="rounded-2xl p-5 max-w-sm w-full" style={{ background: colors.surfaceRaised, border: `1px solid ${colors.borderStrong}` }}>
            <span style={{ fontFamily: fontDisplay, color: colors.text, fontSize: 16, fontWeight: 600 }}>Backfill history from {startDate}?</span>
            <p className="text-sm mt-2 mb-4" style={{ color: colors.textMuted }}>
              This creates a historical record for every occurrence between {startDate} and today, so Category Trends
              reflects it properly. <strong style={{ color: colors.text }}>Your account balance will not change</strong> —
              this is for trend visibility only, not new money moving.
            </p>
            <div className="flex gap-2">
              <button type="button" onClick={() => setShowBackfillConfirm(false)} className="flex-1 rounded-lg py-2 text-sm font-medium" style={{ border: `1px solid ${colors.border}`, color: colors.textMuted }}>Cancel</button>
              <button
                type="button"
                onClick={() => { setShowBackfillConfirm(false); onSave({ ...buildPayload(), backfillForTrends: true }); }}
                className="flex-1 rounded-lg py-2 text-sm font-medium"
                style={{ background: colors.accent, color: colors.bg }}
              >
                Confirm
              </button>
            </div>
          </div>
        </div>
      )}

      {isEditing && (
        <button type="button" onClick={onDelete} disabled={saving} className="w-full rounded-xl py-2.5 text-sm font-medium" style={{ color: colors.alert }}>
          Delete
        </button>
      )}
    </div>
  );
}

export default function ManageRecurringPage() {
  const [accounts, setAccounts] = useState(null);
  const [externalAccounts, setExternalAccounts] = useState([]);
  const [items, setItems] = useState(null);
  const [error, setError] = useState(null);
  const [view, setView] = useState("list"); // "list" | "create" | "edit"
  const [editingItem, setEditingItem] = useState(null);
  const [saving, setSaving] = useState(false);

  async function refresh() {
    try {
      const [accts, extAccts] = await Promise.all([accountsApi.list(), externalBankAccountsApi.list()]);
      setAccounts(accts);
      setExternalAccounts(extAccts);
      // A shared account's recurring-item access is independent of the
      // base account share - the caller might see the account but have
      // no recurring access to it at all (404). Don't let that account's
      // failure wipe out everyone else's recurring items. Also tag each
      // item with whether ITS account is shared (accts[i].sharedFromUserId),
      // since recurring items themselves never carry that field - only
      // the account object does.
      const perAccount = await Promise.all(
        accts.map((a) => recurringApi.list(a.accountId).catch(() => []))
      );
      const flattened = accts.flatMap((a, i) =>
        perAccount[i].map((item) => ({ ...item, accountId: a.accountId, sharedFromUserId: a.sharedFromUserId }))
      );
      setItems(flattened);
    } catch {
      setError("Couldn't load your recurring items.");
    }
  }

  useEffect(() => {
    refresh();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const externalAccountsById = Object.fromEntries(externalAccounts.map((a) => [a.externalBankAccountId, a.name]));
  const income = (items || []).filter((i) => i.isIncome);
  const expenses = (items || []).filter((i) => !i.isIncome);

  async function saveItem(payload) {
    setSaving(true);
    setError(null);
    try {
      const { accountId, ...body } = payload;
      const targetAccountId = editingItem ? editingItem.accountId : accountId;
      if (editingItem) {
        await recurringApi.update(targetAccountId, editingItem.recurringId, body);
      } else {
        await recurringApi.create(targetAccountId, body);
      }
      setView("list");
      setEditingItem(null);
      refresh();
    } catch (err) {
      setError(err.message || "Couldn't save that recurring item.");
    } finally {
      setSaving(false);
    }
  }

  async function deleteItem() {
    if (!editingItem) return;
    setSaving(true);
    try {
      await recurringApi.remove(editingItem.accountId, editingItem.recurringId);
      setView("list");
      setEditingItem(null);
      refresh();
    } catch (err) {
      setError(err.message || "Couldn't delete that item.");
    } finally {
      setSaving(false);
    }
  }

  if (view !== "list") {
    return (
      <div className="min-h-screen" style={{ background: colors.bg, fontFamily: fontBody }}>
        <div className="sticky top-0 z-30 flex items-center gap-3 px-5 py-4" style={{ background: `${colors.bg}E6`, backdropFilter: "blur(8px)", borderBottom: `1px solid ${colors.border}` }}>
          <button onClick={() => { setView("list"); setEditingItem(null); }} aria-label="Back" className="p-1 -ml-1" style={{ color: colors.text }}>
            <ArrowLeft size={20} />
          </button>
          <span style={{ fontFamily: fontDisplay, color: colors.text, fontSize: 19, fontWeight: 600 }}>
            {editingItem ? "Edit recurring" : "New recurring"}
          </span>
        </div>
        {error && <p className="text-sm px-5 pt-4" style={{ color: colors.alert }}>{error}</p>}
        <RecurringForm
          accounts={accounts || []}
          externalAccounts={externalAccounts}
          initial={editingItem}
          saving={saving}
          onCancel={() => { setView("list"); setEditingItem(null); }}
          onSave={saveItem}
          onDelete={deleteItem}
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen pb-10" style={{ background: colors.bg, fontFamily: fontBody }}>
      <PageHeader title="Recurring" />

      <div className="px-5 pt-6 max-w-md mx-auto">
        {error && <p className="text-sm mb-4" style={{ color: colors.alert }}>{error}</p>}

        <button type="button" onClick={() => setView("create")} disabled={!accounts || accounts.length === 0} className="w-full rounded-2xl py-3 mb-6 text-sm font-medium flex items-center justify-center gap-2" style={{ border: `1px dashed ${colors.borderStrong}`, color: colors.textMuted }}>
          <Plus size={16} />
          Add recurring income or expense
        </button>

        <h3 style={{ fontFamily: fontDisplay, color: colors.text, fontSize: 15, fontWeight: 600 }} className="mb-1 px-1">Income</h3>
        <div className="rounded-2xl px-4 mb-6 relative overflow-hidden" style={{ background: colors.surface, border: `1px solid ${colors.border}` }}>
          <PerfEdge />
          <div className="pt-1">
            {items === null && !error ? (
              <p className="text-sm py-4 text-center" style={{ color: colors.textMuted }}>Loading…</p>
            ) : income.length === 0 ? (
              <p className="text-sm py-4 text-center" style={{ color: colors.textMuted }}>No recurring income yet.</p>
            ) : (
              income.map((item) => (
                <RecurringListRow key={item.recurringId} item={item} externalAccountsById={externalAccountsById} onSelect={() => { setEditingItem(item); setView("edit"); }} />
              ))
            )}
          </div>
        </div>

        <h3 style={{ fontFamily: fontDisplay, color: colors.text, fontSize: 15, fontWeight: 600 }} className="mb-1 px-1">Expenses</h3>
        <div className="rounded-2xl px-4 relative overflow-hidden" style={{ background: colors.surface, border: `1px solid ${colors.border}` }}>
          <PerfEdge />
          <div className="pt-1">
            {items === null && !error ? (
              <p className="text-sm py-4 text-center" style={{ color: colors.textMuted }}>Loading…</p>
            ) : expenses.length === 0 ? (
              <p className="text-sm py-4 text-center" style={{ color: colors.textMuted }}>No recurring expenses yet.</p>
            ) : (
              expenses.map((item) => (
                <RecurringListRow key={item.recurringId} item={item} externalAccountsById={externalAccountsById} onSelect={() => { setEditingItem(item); setView("edit"); }} />
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
