import React, { useEffect, useState } from "react";
import { ArrowLeft, Plus, ChevronDown, X, AlertTriangle, HelpCircle } from "lucide-react";
import { budgetsApi, projectionsApi } from "../lib/apiClient";
import PageHeader from "../components/PageHeader";
import { colors, fontDisplay, fontBody, fontMono, formatMoney } from "../lib/theme";

function InfoBubble({ text }) {
  const [open, setOpen] = useState(false);
  return (
    <span className="relative inline-flex align-middle ml-1.5">
      <button type="button" onClick={() => setOpen((o) => !o)} aria-label="More information" style={{ width: 16, height: 16, color: colors.textMuted }}>
        <HelpCircle size={14} strokeWidth={2} />
      </button>
      {open && (
        <div className="absolute z-30 left-0 top-6 w-64 rounded-lg p-3 text-xs shadow-xl" style={{ background: colors.surfaceRaised, border: `1px solid ${colors.borderStrong}`, color: colors.text }}>
          {text}
          <button onClick={() => setOpen(false)} className="block mt-2 text-xs underline" style={{ color: colors.accentLight }}>Got it</button>
        </div>
      )}
    </span>
  );
}

const CATEGORY_OPTIONS = ["Groceries", "Dining", "Utilities", "Transportation", "Household", "Entertainment", "Health", "Rent/Mortgage"];

function PerfEdge() {
  return <div className="absolute top-0 left-0 right-0 h-px" style={{ backgroundImage: `repeating-linear-gradient(90deg, ${colors.borderStrong} 0, ${colors.borderStrong} 5px, transparent 5px, transparent 11px)` }} />;
}

function BudgetCard({ budget, onClick }) {
  if (budget.isUpcoming) {
    return (
      <button
        type="button"
        onClick={onClick}
        className="w-full text-left rounded-2xl p-4 mb-3 relative overflow-hidden"
        style={{ background: colors.surface, border: `1px dashed ${colors.borderStrong}` }}
      >
        <PerfEdge />
        <div className="flex items-center justify-between">
          <span className="text-sm font-medium" style={{ color: colors.text }}>{budget.category}</span>
          <span className="text-xs" style={{ fontFamily: fontMono, color: colors.textMuted }}>{formatMoney(budget.monthlyAmount)}/mo</span>
        </div>
        <p className="text-xs mt-1" style={{ color: colors.accentLight }}>Starts {budget.effectiveStartDate}</p>
      </button>
    );
  }

  const spent = budget.spentAmount || 0;
  const percent = (spent / budget.monthlyAmount) * 100;
  const over = percent >= 100;
  const near = percent >= 80 && percent < 100;
  const barColor = over ? colors.alert : near ? "#D6A24C" : colors.accentLight;

  return (
    <button
      type="button"
      onClick={onClick}
      className="w-full text-left rounded-2xl p-4 mb-3 relative overflow-hidden"
      style={{ background: colors.surface, border: `1px solid ${over ? colors.alert : colors.border}` }}
    >
      <PerfEdge />
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-1.5">
          <span className="text-sm font-medium" style={{ color: colors.text }}>{budget.category}</span>
          {over && <AlertTriangle size={13} style={{ color: colors.alert }} />}
        </div>
        <span className="text-xs" style={{ fontFamily: fontMono, color: colors.textMuted }}>
          {formatMoney(spent)} / {formatMoney(budget.monthlyAmount)}
        </span>
      </div>
      <div className="h-2 rounded-full overflow-hidden mb-2" style={{ background: colors.surfaceRaised }}>
        <div className="h-full rounded-full" style={{ width: `${Math.min(percent, 100)}%`, background: barColor }} />
      </div>
      <span className="text-xs" style={{ color: over ? colors.alert : near ? "#D6A24C" : colors.textMuted, fontFamily: fontMono }}>
        {over ? `${(percent - 100).toFixed(0)}% over budget` : `${percent.toFixed(0)}% used`}
      </span>
    </button>
  );
}

function NewBudgetForm({ initial, onCancel, onSave, onDelete, saving }) {
  const isEditing = !!initial;
  const [category, setCategory] = useState(initial?.category ?? CATEGORY_OPTIONS[0]);
  const [addingCategory, setAddingCategory] = useState(false);
  const [customCategory, setCustomCategory] = useState("");
  const [amount, setAmount] = useState(initial?.monthlyAmount != null ? String(initial.monthlyAmount) : "");
  const [startDate, setStartDate] = useState(initial?.startDate ?? new Date().toISOString().slice(0, 10));
  const [showBackfillConfirm, setShowBackfillConfirm] = useState(false);

  const effectiveCategory = addingCategory ? customCategory.trim() : category;

  return (
    <div className="rounded-2xl p-4 mb-4" style={{ background: colors.surfaceRaised, border: `1px solid ${colors.borderStrong}` }}>
      <div className="flex items-center justify-between mb-3">
        <span style={{ fontFamily: fontDisplay, color: colors.text, fontSize: 15, fontWeight: 600 }}>{isEditing ? "Edit budget" : "New budget"}</span>
        <button onClick={onCancel} aria-label="Cancel" style={{ color: colors.textMuted }}><X size={16} /></button>
      </div>
      <div className="flex items-center mb-1.5">
        <label className="text-xs uppercase tracking-wide" style={{ color: colors.textMuted, letterSpacing: "0.08em" }}>Category</label>
        <InfoBubble text="Budgets aggregate across every account you have — the same category is tracked together regardless of which account a purchase was made on. This also determines which transactions count toward this budget on the Dashboard and in Projections." />
      </div>
      {isEditing ? (
        <p className="text-sm mb-3 px-3 py-2.5 rounded-lg" style={{ background: colors.bg, border: `1px solid ${colors.border}`, color: colors.textMuted }}>
          {category} <span className="text-xs">(category can't be changed once created)</span>
        </p>
      ) : addingCategory ? (
        <div className="flex gap-2 mb-3">
          <input
            autoFocus
            value={customCategory}
            onChange={(e) => setCustomCategory(e.target.value)}
            placeholder="New category name"
            className="flex-1 rounded-lg px-3 py-2.5 text-sm focus:outline-none"
            style={{ background: colors.bg, border: `1px solid ${colors.border}`, color: colors.text }}
          />
          <button onClick={() => { setAddingCategory(false); setCustomCategory(""); }} className="rounded-lg px-3 text-xs" style={{ border: `1px solid ${colors.border}`, color: colors.textMuted }}>Cancel</button>
        </div>
      ) : (
        <div className="relative mb-3">
          <select
            value={category}
            onChange={(e) => {
              if (e.target.value === "__new__") { setAddingCategory(true); }
              else { setCategory(e.target.value); }
            }}
            className="w-full appearance-none rounded-lg px-3 py-2.5 text-sm focus:outline-none"
            style={{ background: colors.bg, border: `1px solid ${colors.border}`, color: colors.text }}
          >
            {CATEGORY_OPTIONS.map((c) => <option key={c} value={c}>{c}</option>)}
            <option value="__new__">+ Add a new category…</option>
          </select>
          <ChevronDown size={16} className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" style={{ color: colors.textMuted }} />
        </div>
      )}
      <div className="flex items-center mb-1.5">
        <label className="text-xs uppercase tracking-wide" style={{ color: colors.textMuted, letterSpacing: "0.08em" }}>Monthly amount</label>
        <InfoBubble text="This is what triggers your budget alerts: an email at 80% spent, when you first go over, and again on every new purchase while you're still over — if those alerts are turned on in Settings." />
      </div>
      <div className="relative mb-3">
        <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm" style={{ color: colors.textMuted, fontFamily: fontMono }}>$</span>
        <input type="number" inputMode="decimal" value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="0.00" className="w-full rounded-lg pl-6 pr-3 py-2.5 text-sm focus:outline-none" style={{ background: colors.bg, border: `1px solid ${colors.border}`, color: colors.text, fontFamily: fontMono }} />
      </div>
      {!isEditing && (
        <>
          <div className="flex items-center mb-1.5">
            <label className="text-xs uppercase tracking-wide" style={{ color: colors.textMuted, letterSpacing: "0.08em" }}>Start date</label>
            <InfoBubble text="Snapped forward to your next scheduled paycheck automatically, so a budget period never splits a pay period in half. If you don't have recurring income set up yet, it starts on the date you pick." />
          </div>
          <input type="date" value={startDate} min={new Date(Date.now() - 365 * 86400000).toISOString().slice(0, 10)} onChange={(e) => setStartDate(e.target.value)} className="w-full rounded-lg px-3 py-2.5 mb-4 text-sm focus:outline-none" style={{ background: colors.bg, border: `1px solid ${colors.border}`, color: colors.text, colorScheme: "dark" }} />
        </>
      )}
      <button
        type="button"
        disabled={!amount || parseFloat(amount) <= 0 || !effectiveCategory || saving}
        onClick={() => {
          const isPastDate = !isEditing && startDate < new Date().toISOString().slice(0, 10);
          if (isPastDate) setShowBackfillConfirm(true);
          else onSave({ category: effectiveCategory, monthlyAmount: parseFloat(amount), startDate });
        }}
        className="w-full rounded-lg py-2.5 text-sm font-medium"
        style={{ background: !amount || parseFloat(amount) <= 0 || !effectiveCategory ? colors.surface : colors.accent, color: !amount || parseFloat(amount) <= 0 || !effectiveCategory ? colors.textMuted : colors.bg, opacity: saving ? 0.6 : 1 }}
      >
        {saving ? "Saving…" : isEditing ? "Save changes" : "Save budget"}
      </button>

      {showBackfillConfirm && (
        <div className="fixed inset-0 flex items-center justify-center px-6 z-50" style={{ background: "rgba(15,27,45,0.8)" }}>
          <div className="rounded-2xl p-5 max-w-sm w-full" style={{ background: colors.surfaceRaised, border: `1px solid ${colors.borderStrong}` }}>
            <span style={{ fontFamily: fontDisplay, color: colors.text, fontSize: 16, fontWeight: 600 }}>Start this budget from {startDate}?</span>
            <p className="text-sm mt-2 mb-4" style={{ color: colors.textMuted }}>
              This budget will use your real spending history for {effectiveCategory} starting from {startDate}, instead
              of starting fresh today. <strong style={{ color: colors.text }}>Your account balance is never affected by
              budgets</strong> either way.
            </p>
            <div className="flex gap-2">
              <button type="button" onClick={() => setShowBackfillConfirm(false)} className="flex-1 rounded-lg py-2 text-sm font-medium" style={{ border: `1px solid ${colors.border}`, color: colors.textMuted }}>Cancel</button>
              <button
                type="button"
                onClick={() => { setShowBackfillConfirm(false); onSave({ category: effectiveCategory, monthlyAmount: parseFloat(amount), startDate, backfillForTrends: true }); }}
                className="flex-1 rounded-lg py-2 text-sm font-medium"
                style={{ background: colors.accent, color: colors.bg }}
              >
                Confirm
              </button>
            </div>
          </div>
        </div>
      )}

      {isEditing && (
        <button
          type="button"
          onClick={onDelete}
          disabled={saving}
          className="w-full rounded-lg py-2.5 text-sm font-medium mt-2"
          style={{ color: colors.alert }}
        >
          Delete this budget
        </button>
      )}
    </div>
  );
}

export default function BudgetsPage() {
  const [budgets, setBudgets] = useState(null);
  const [projections, setProjections] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [editingBudget, setEditingBudget] = useState(null);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);

  async function refresh() {
    try {
      // GET /budgets now returns spentAmount per category directly (see
      // lambda/budgets/index.py _list_budgets) - no need to pull every
      // account's transactions client-side just to render a progress bar.
      const [b, p] = await Promise.all([budgetsApi.list(), projectionsApi.get()]);
      setBudgets(b);
      setProjections(p);
    } catch {
      setError("Couldn't load your budgets.");
    }
  }

  useEffect(() => {
    refresh();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function saveBudget(payload) {
    setSaving(true);
    try {
      // POST /budgets is an upsert keyed by category - editing an existing
      // budget uses the exact same call as creating a new one.
      await budgetsApi.upsert(payload);
      setShowForm(false);
      setEditingBudget(null);
      refresh();
    } catch (err) {
      setError(err.message || "Couldn't save that budget.");
    } finally {
      setSaving(false);
    }
  }

  async function deleteBudget() {
    if (!editingBudget) return;
    setSaving(true);
    try {
      await budgetsApi.remove(editingBudget.sk);
      setShowForm(false);
      setEditingBudget(null);
      refresh();
    } catch (err) {
      setError(err.message || "Couldn't delete that budget.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="min-h-screen pb-10" style={{ background: colors.bg, fontFamily: fontBody }}>
      <PageHeader title="Budgets" />

      <div className="px-5 pt-6 max-w-md mx-auto">
        {error && <p className="text-sm mb-4" style={{ color: colors.alert }}>{error}</p>}

        {projections && (
          <div className="rounded-2xl p-4 mb-5 relative overflow-hidden" style={{ background: colors.surface, border: `1px solid ${colors.border}` }}>
            <PerfEdge />
            <p className="text-xs uppercase tracking-wide mb-1" style={{ color: colors.textMuted, letterSpacing: "0.08em" }}>This period</p>
            <p style={{ fontFamily: fontMono, fontSize: 20, color: colors.text }}>
              {formatMoney(projections.spentSoFarThisPeriod)}{" "}
              <span style={{ color: colors.textMuted, fontSize: 14 }}>of {formatMoney(projections.totalBudgeted)}</span>
            </p>
          </div>
        )}

        {showForm ? (
          <NewBudgetForm
            key={editingBudget?.sk ?? "new"}
            initial={editingBudget}
            onCancel={() => { setShowForm(false); setEditingBudget(null); }}
            onSave={saveBudget}
            onDelete={deleteBudget}
            saving={saving}
          />
        ) : (
          <button onClick={() => { setEditingBudget(null); setShowForm(true); }} className="w-full rounded-2xl py-3 mb-5 text-sm font-medium flex items-center justify-center gap-2" style={{ border: `1px dashed ${colors.borderStrong}`, color: colors.textMuted }}>
            <Plus size={16} />
            Add a budget
          </button>
        )}

        <h3 style={{ fontFamily: fontDisplay, color: colors.text, fontSize: 15, fontWeight: 600 }} className="mb-1 px-1">By category</h3>

        {budgets === null && !error && <p className="text-sm" style={{ color: colors.textMuted }}>Loading…</p>}
        {budgets !== null && budgets.length === 0 && <p className="text-sm" style={{ color: colors.textMuted }}>No budgets yet.</p>}
        {(budgets || []).map((b) => (
          <BudgetCard key={b.sk} budget={b} onClick={() => { setEditingBudget(b); setShowForm(true); }} />
        ))}
      </div>
    </div>
  );
}
