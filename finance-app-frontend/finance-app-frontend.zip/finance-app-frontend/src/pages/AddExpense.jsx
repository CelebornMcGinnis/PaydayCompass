import React, { useEffect, useMemo, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { ArrowLeft, Plus, Trash2, ChevronDown } from "lucide-react";
import { accountsApi, transactionsApi } from "../lib/apiClient";
import { colors, fontDisplay, fontBody, fontMono, formatMoney } from "../lib/theme";
import PageHeader from "../components/PageHeader";

const CATEGORIES = ["Uncategorized", "Groceries", "Household", "Dining", "Transportation", "Utilities", "Entertainment", "Health", "Rent/Mortgage"];

function uid() {
  return Math.random().toString(36).slice(2, 9);
}

export default function AddExpensePage() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const presetAccountId = searchParams.get("accountId");

  const [accounts, setAccounts] = useState(null);
  const [accountId, setAccountId] = useState(presetAccountId || "");
  const [totalAmount, setTotalAmount] = useState("");
  const [primaryCategory, setPrimaryCategory] = useState("Uncategorized");
  const [description, setDescription] = useState("");
  const [splits, setSplits] = useState([]);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    accountsApi.list().then((data) => {
      setAccounts(data);
      if (!accountId && data.length > 0) setAccountId(data[0].accountId);
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const total = parseFloat(totalAmount) || 0;
  const splitSum = useMemo(() => splits.reduce((sum, s) => sum + (parseFloat(s.amount) || 0), 0), [splits]);
  const remaining = total - splitSum;
  const overAllocated = remaining < -0.001;

  function addSplit() {
    setSplits((s) => [...s, { id: uid(), amount: "", category: "Uncategorized" }]);
  }
  function updateSplit(id, next) {
    setSplits((s) => s.map((sp) => (sp.id === id ? next : sp)));
  }
  function removeSplit(id) {
    setSplits((s) => s.filter((sp) => sp.id !== id));
  }

  async function handleSave() {
    if (total <= 0 || overAllocated || !accountId) return;
    setSaving(true);
    setError(null);

    // Matches the backend contract exactly: splits (including the
    // unsplit remainder under primaryCategory) must sum to totalAmount -
    // see lambda/transactions/index.py _add_expense.
    const finalSplits = [
      ...(remaining > 0.001 ? [{ amount: remaining, category: primaryCategory }] : []),
      ...splits.filter((s) => parseFloat(s.amount) > 0).map((s) => ({ amount: parseFloat(s.amount), category: s.category })),
    ];

    try {
      await transactionsApi.addExpense(accountId, {
        totalAmount: total,
        splits: finalSplits,
        description: description || undefined,
      });
      navigate(`/accounts/${accountId}`);
    } catch (err) {
      setError(err.message || "Couldn't save this expense - try again.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="min-h-screen pb-28" style={{ background: colors.bg, fontFamily: fontBody }}>
      <PageHeader title="Add expense" />

      <div className="px-5 pt-6 max-w-md mx-auto">
        {accounts === null ? (
          <p className="text-sm" style={{ color: colors.textMuted }}>Loading your accounts…</p>
        ) : (
          <>
            <div className="mb-5">
              <label className="text-xs uppercase tracking-wide block mb-1.5" style={{ color: colors.textMuted, letterSpacing: "0.08em" }}>Account</label>
              <div className="relative">
                <select
                  value={accountId}
                  onChange={(e) => setAccountId(e.target.value)}
                  className="w-full appearance-none rounded-lg px-3 py-2.5 text-sm focus:outline-none"
                  style={{ background: colors.bg, border: `1px solid ${colors.border}`, color: colors.text }}
                >
                  {accounts.map((a) => <option key={a.accountId} value={a.accountId}>{a.name}</option>)}
                </select>
                <ChevronDown size={16} className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" style={{ color: colors.textMuted }} />
              </div>
            </div>

            <div className="rounded-2xl p-5 mb-5" style={{ background: colors.surface, border: `1px solid ${colors.border}` }}>
              <label className="text-xs uppercase tracking-wide block mb-2" style={{ color: colors.textMuted, letterSpacing: "0.08em" }}>Total amount</label>
              <div className="relative mb-4">
                <span className="absolute left-0 top-1/2 -translate-y-1/2 text-2xl" style={{ color: colors.textMuted, fontFamily: fontMono }}>$</span>
                <input
                  type="number"
                  inputMode="decimal"
                  value={totalAmount}
                  onChange={(e) => setTotalAmount(e.target.value)}
                  placeholder="0.00"
                  autoFocus
                  className="w-full pl-6 py-1 text-3xl bg-transparent focus:outline-none"
                  style={{ color: colors.text, fontFamily: fontMono, border: "none" }}
                />
              </div>
              <label className="text-xs uppercase tracking-wide block mb-1.5" style={{ color: colors.textMuted, letterSpacing: "0.08em" }}>Category</label>
              <div className="relative">
                <select
                  value={primaryCategory}
                  onChange={(e) => setPrimaryCategory(e.target.value)}
                  className="w-full appearance-none rounded-lg px-3 py-2.5 text-sm focus:outline-none"
                  style={{ background: colors.bg, border: `1px solid ${colors.border}`, color: colors.text }}
                >
                  {CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
                </select>
                <ChevronDown size={16} className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" style={{ color: colors.textMuted }} />
              </div>
            </div>

            <div className="flex items-center mb-3 px-1">
              <h3 style={{ fontFamily: fontDisplay, color: colors.text, fontSize: 16, fontWeight: 600 }}>Split into categories</h3>
              <span className="text-xs ml-1.5" style={{ color: colors.textMuted }}>(optional)</span>
            </div>

            {splits.map((s) => (
              <div key={s.id} className="rounded-xl p-3 mb-2.5" style={{ background: colors.surfaceRaised, border: `1px solid ${colors.border}` }}>
                <div className="flex items-start gap-2">
                  <div className="flex-1">
                    <input
                      type="number"
                      inputMode="decimal"
                      value={s.amount}
                      onChange={(e) => updateSplit(s.id, { ...s, amount: e.target.value })}
                      placeholder="0.00"
                      className="w-full rounded-lg px-3 py-2 text-sm focus:outline-none"
                      style={{ background: colors.bg, border: `1px solid ${colors.border}`, color: colors.text, fontFamily: fontMono }}
                    />
                  </div>
                  <div className="flex-1">
                    <select
                      value={s.category}
                      onChange={(e) => updateSplit(s.id, { ...s, category: e.target.value })}
                      className="w-full rounded-lg px-2.5 py-2 text-sm focus:outline-none"
                      style={{ background: colors.bg, border: `1px solid ${colors.border}`, color: colors.text }}
                    >
                      {CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
                    </select>
                  </div>
                  <button type="button" onClick={() => removeSplit(s.id)} aria-label="Remove split" className="mt-1 p-2 rounded-lg shrink-0" style={{ color: colors.alert }}>
                    <Trash2 size={16} />
                  </button>
                </div>
              </div>
            ))}

            <button
              type="button"
              onClick={addSplit}
              className="w-full rounded-xl py-2.5 mb-5 text-sm font-medium flex items-center justify-center gap-2"
              style={{ border: `1px dashed ${colors.borderStrong}`, color: colors.textMuted }}
            >
              <Plus size={15} />
              Add category split
            </button>

            {total > 0 && (
              <div className="rounded-xl px-4 py-3 mb-5 flex items-center justify-between" style={{ background: colors.surfaceRaised, border: `1px solid ${overAllocated ? colors.alert : colors.border}` }}>
                <span className="text-xs" style={{ color: colors.textMuted }}>{overAllocated ? "Over-allocated by" : "Remaining from total"}</span>
                <span style={{ fontFamily: fontMono, fontSize: 15, color: overAllocated ? colors.alert : colors.positive }}>
                  {formatMoney(Math.abs(remaining))}
                </span>
              </div>
            )}

            <div className="mb-6">
              <label className="text-xs uppercase tracking-wide block mb-1.5" style={{ color: colors.textMuted, letterSpacing: "0.08em" }}>
                Description <span style={{ opacity: 0.6 }}>(optional)</span>
              </label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value.slice(0, 250))}
                rows={2}
                placeholder="What was this for?"
                className="w-full rounded-lg px-3 py-2.5 text-sm focus:outline-none resize-none"
                style={{ background: colors.surface, border: `1px solid ${colors.border}`, color: colors.text }}
              />
              <p className="text-[11px] text-right mt-1" style={{ color: colors.textMuted }}>{description.length}/250</p>
            </div>

            {error && <p className="text-sm mb-4" style={{ color: colors.alert }}>{error}</p>}
          </>
        )}
      </div>

      <div className="fixed bottom-0 left-0 right-0 px-5 py-4 z-30" style={{ background: colors.surface, borderTop: `1px solid ${colors.border}` }}>
        <div className="max-w-md mx-auto">
          <button
            type="button"
            onClick={handleSave}
            disabled={total <= 0 || overAllocated || saving || !accountId}
            className="w-full rounded-xl py-3 text-sm font-medium transition-opacity"
            style={{
              background: total <= 0 || overAllocated || !accountId ? colors.surfaceRaised : colors.accent,
              color: total <= 0 || overAllocated || !accountId ? colors.textMuted : colors.bg,
              cursor: total <= 0 || overAllocated ? "not-allowed" : "pointer",
              opacity: saving ? 0.6 : 1,
            }}
          >
            {saving ? "Saving…" : "Save expense"}
          </button>
        </div>
      </div>
    </div>
  );
}
