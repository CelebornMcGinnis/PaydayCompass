# Personal Finance App — CDK Infrastructure

Serverless architecture: S3 + CloudFront (unified domain, fronting both the
static site and API Gateway) → API Gateway → Lambda (Python) → DynamoDB,
with Cognito (Plus tier) for auth and SES for threshold-based email alerts.

## Item 13: retroactive date entry with confirmation

**Recurring** (income/expense): a past `startDate` (up to 1 year back)
generates real transaction records for every missed occurrence between
that date and today, tagged `isRetroactiveEntry: true`, requiring explicit
opt-in via a `backfillForTrends: true` flag - the frontend only sets this
after the user confirms a dialog explaining exactly what happens. The
template's `nextDueDate` is set to the first occurrence on/after today,
so the normal daily processor never re-touches the backfilled dates.
Deliberately does NOT touch the account balance - the whole point is
describing history that's already reflected in today's real balance, not
new money moving. Verified the occurrence-generation logic empirically
(not just reasoned about): reproduced a real backfill sequence and
asserted every generated date is before today and the resulting
`nextDueDate` is on/after today.

**Budgets**: needed far less new logic than it looked like - budget
spend was already computed live from real transaction history starting
at `effectiveStartDate`, so a past date already pulled in real historical
spend with zero backfill needed. Just added the same 1-year cap and
confirmation-required pattern for consistency and to set expectations
accurately (budgets never touch balance either way, past or present).

**One real design tension, resolved and documented in code, not silently
decided**: Account Detail's balance-trend chart is reconstructed backward
from the real current balance through transaction history. Retroactive
entries are excluded from that specific reconstruction (they'd otherwise
show balance dips/gains that never happened) but still count normally in
Category Trends and Budget spend calculations, which are about real
historical spend, not balance reconstruction. Backfilled transactions are
also visibly tagged "· backfilled for trends" in the transaction list.

## Feedback-round fixes (backend), round 3 — real Sharing table schema bug

Found while implementing "share multiple accounts with one person, one
email": the Sharing table's key was `(ownerUserId, invitedUserId)` with
**no account in the key at all**. This meant at most ONE share could ever
exist between a given owner and invited user - sharing a *second* account
with the same person would silently `put_item` over (and destroy) the
first share, with no error, no warning. This was a pre-existing bug, not
something the batch-sharing feature introduced - it just surfaced it.

**Fixed**: sort key changed to `shareKey = "{invitedUserId}#{accountId}"`.
`invitedUserId` remains a plain attribute (not part of the key) so the
`byInvitedUser` GSI is unaffected. This is a genuine table replacement
(DynamoDB can't change key schema in place) - confirmed safe given no real
users/data exist yet, matching the same situation as the earlier
`hasCompletedSetup` Cognito attribute change.

Also added:
- `_create_invites` now accepts `accountIds` (a list) instead of a single
  `accountId`, creating one row per account but sending exactly ONE email
  (via new `_send_invite_email`, using `sharingFn`'s new SES permission)
  regardless of how many accounts were included.
- `_respond_to_invites` (PUT) now accepts/declines every pending share
  from that owner to the caller at once, not one row at a time - the
  batch-accept counterpart to the batch-invite.
- `DELETE /sharing/{invitationId}` (owner revokes every share, any
  status, extended to that invited user) - didn't exist at all before.
- Found and fixed one more place still using the old key shape:
  `account_deletion/index.py`'s sharing-record cleanup.

Confirmed directly in the synthesized CloudFormation template (not just
assumed from source): the new `shareKey` sort key, and the new DELETE
method resource.

## Feedback-round fixes (backend), round 2

- **`budgets-fn`**: added `DELETE /budgets/{sk}` - there was no way to
  delete a budget at all before this (only create/upsert existed).
  `{sk}` is `category#effectiveStartDate`, which contains a literal `#`,
  so the frontend must `encodeURIComponent` it - confirmed present as a
  real API Gateway Method resource in the synthesized template, not just
  assumed from the CDK source.
- **`payday-fn`**: `_get_upcoming`'s expense window now extends 5 days
  past the next payday (previously cut off exactly at payday), tagging
  each expense `isAfterPayday` so the frontend can show it separately as
  informational rather than folding it into what actually gets submitted
  and paid this cycle.

## Feedback-round fixes (backend)

- **`sharing-fn`**: `GET /sharing` now resolves and includes the account
  owner's email on every `asInvited` entry (`ownerEmail`, via the same
  `lookup_email_by_sub` used elsewhere). Previously an invited user had
  no way to know who was sharing an account with them at all - not even
  an email - since the record only ever stored the owner's raw Cognito
  user id.
- **`budgets-fn`**: `_list_budgets` now returns every category's latest
  budget regardless of whether its (paycheck-snapped) start date has
  arrived yet, tagged `isUpcoming` when it hasn't. Previously a
  newly-created budget was invisible in the list until its effective
  start date arrived - which is often days away - making a successful
  save indistinguishable from a silent failure. `spentAmount` is only
  computed for budgets actually in effect; `get_active_budgets` (used by
  projections/notifications, which correctly should only count budgets
  actually in effect) is unchanged.

## Structure

```
bin/finance-app.ts       Entry point — instantiates FinanceApp-Beta and FinanceApp-Prod
config/environments.ts   Per-environment config (naming prefix, tags, retention, Cognito tier)
lib/finance-app-stack.ts Main stack — wires all constructs together, applies tags
lib/constructs/
  data-tables.ts          DynamoDB tables (Accounts, Transactions, Budgets, Recurring, AuditLog, Sharing, ...)
  auth.ts                 Cognito User Pool (Plus tier toggle per environment)
  lambdas.ts              All Lambda functions, least-privilege IAM per function
  api.ts                  API Gateway routes + Cognito authorizer
  frontend.ts             S3 bucket + CloudFront (routes /api/* to API Gateway, else to S3)
  observability.ts        CloudWatch alarms, SNS alert topic, DLQ for the daily job
  shared-layer.ts         The finance_common Lambda Layer construct
lambda/                   Python handler source per function
lambda-layers/finance-common/python/finance_common/
                          Shared logic used by multiple functions - see below
```

## Shared Lambda Layer

Three near-identical implementations of the recurring-schedule math (in
`budgets/`, `payday/`, `recurring_processor/`) and three of the budget-
notification-check logic (in `csv_import_export/`, `recurring_processor/`,
`transactions/`) used to be copy-pasted independently, with nothing
enforcing they stayed in sync. That logic now lives once, in
`lambda-layers/finance-common/python/finance_common/`, as a Lambda Layer
attached to every function that needs it:

- `schedule.py` — recurring-transaction date math (pure functions)
- `cognito_lookup.py` — email ↔ Cognito sub lookups
- `budget_notify.py` — active-budget lookup, cross-account category spend,
  and the "invoke notifications-fn" trigger

Two real bugs surfaced while consolidating this:
1. `sharing-fn` called Cognito's `list_users` but never had the IAM
   permission to do so - the sharing invite flow would have failed at
   runtime. Fixed.
2. `budgets/index.py`'s local copy of the spend-aggregation query never
   filtered to `direction == "debit"`, unlike every other copy - meaning
   budget "spent" totals and `spentSoFarThisPeriod` in projections could
   have been inflated by credits (refunds, one-time income) landing in
   that category. Fixed by consolidating onto the shared (correct) version.

## Observability & Reliability

- **`lib/constructs/observability.ts`** — CloudWatch alarms on the two
  functions that run unattended (`recurring-processor-fn`,
  `notifications-fn`), an SNS topic that emails `cfg.alertEmail` when
  either errors, and a dead-letter queue on the daily recurring schedule
  so a failed run is captured for inspection instead of vanishing.
- **User-facing failure notification:** each recurring template is now
  processed in its own try/except inside `recurring_processor/index.py` -
  one bad template no longer aborts every other user's due payments for
  the day. The affected user gets a direct "we couldn't process your
  recurring payment" email same-day; the function still re-raises after
  the loop if anything failed, so the CloudWatch alarm/DLQ above still
  fire too - the user finding out and you finding out are two separate,
  both-necessary things.
- **REQUIRED before your first prod deploy:** set `alertEmail` in
  `config/environments.ts` to a real address you monitor. It ships with a
  placeholder (`you@example.com`) that won't receive anything.
- Every Lambda has log retention configured (2 weeks in beta, 3 months in
  prod) instead of the previous unbounded default.

## CI/CD

`.github/workflows/deploy.yml` — validates (type-check + synth both
stacks) on every push/PR, auto-deploys beta on push to `main`, and deploys
prod behind a required manual approval (configure reviewers under repo
Settings → Environments → `production`). Needs `AWS_ACCESS_KEY_ID` /
`AWS_SECRET_ACCESS_KEY` repo secrets (or swap for OIDC role assumption —
see the comment at the top of the workflow file).

## Shared-Account Authorization & Activity Alerts

Sharing an account with "edit" permission was, until recently, stored but
not actually enforced or usable:
- `GET /accounts/{id}/transactions` had no ownership check at all - any
  signed-in user who knew an accountId could read its history
- Every write keyed its balance update by the CALLER's own user id rather
  than the account's real owner - a shared "edit" user attempting to use
  that access would have silently created a phantom Accounts-table item
  instead of updating the real account

Fixed via `finance_common.sharing_access.resolve_account_access` (owns-it
or has-an-accepted-share, at what permission), applied to every
`/accounts/{id}/transactions` route, `/accounts/{id}/income`, and
`GET /accounts` (which now also returns accounts shared *with* the caller,
previously invisible to them). `transactions-fn`'s writes are also
correctly keyed by the resolved owner now, not the actor.

**Provenance & transparency:** when the acting user differs from the
account owner, transactions are stamped `addedByUserId`
(`GET /transactions` resolves this to `addedByEmail`), and the owner gets
an email via `finance_common.shared_activity_alerts` whenever a shared
editor adds, edits, or deletes something. Defaults ON for every user
(transparency-first) - opt-out is a `PUT /preferences` call
(`sharedActivityAlertsEnabled: false`), backed by the new
`user-preferences-fn` / UserPreferences table. No frontend UI for this
toggle exists yet; when Settings gets wired, add it there. Also worth
adding to the Getting Setup wizard once it's wired: a step or link that
takes the user to communication/notification settings, so they know this
exists and can adjust it early rather than discovering it later.

`_transfer` (between a user's own accounts) was deliberately left
untouched - it still requires ownership of both accounts, which is
correct as designed; a transfer involving someone else's shared account is
a different feature (closer to the peer fund-movement notifications) and
wasn't part of this fix.

**Recurring templates had the identical gap** (`recurring-fn`'s list,
update, delete, and occurrence-override routes had no ownership check;
create stamped the caller's own id instead of the account owner's) - fixed
the same way, plus the same provenance stamping and shared-activity alerts.
While in there, `PUT /accounts/{id}/recurring/{id}` was also still a
`501 not implemented` stub from earlier in the project - implemented
properly (partial-update semantics, sticky externalBankAccountId/
grossAmount fields, no silent nextDueDate recomputation on a frequency
change - the caller must set that explicitly if they're changing the
schedule).

**Budget-threshold and low-balance alert preferences**: budget-threshold
alerts (the existing 80%/100%/repeat-over-100% emails) can now actually be
turned off (`budgetAlertsEnabled` in `/preferences` - previously always-on
with no opt-out). Low-balance alerts are a genuinely new feature, not
previously built at all: `finance_common.low_balance_alerts` checks every
balance-changing operation in `transactions-fn` (add expense, add income,
edit, delete, transfer) and `recurring-processor-fn` against a per-user
threshold (`lowBalanceThresholdAmount`), off by default and a no-op until
a threshold is actually set. Not yet wired into `reconcile-fn`,
`csv_import_export`, or `payday-fn`'s submit path - left open, not ruled
out.

## Recurring-Expense Sharing

The Sharing table already fully modeled per-data-type sharing at the data
layer (`dataPermissions.recurring`, set at invite time via
`sharing-fn`'s `POST /sharing`), but two things stood between that and it
actually working:

1. **`recurring-fn` never checked it** - it gated everything on the flat
   base `accountPermission` instead, which is a different, independent
   knob by design (a user could have view-only access to an account's
   transactions while having full edit access to its recurring templates,
   or the reverse). Fixed: `resolve_account_access` now also returns the
   raw `dataPermissions` map, and `recurring-fn` gates on
   `dataPermissions.recurring` specifically for non-owners, defaulting to
   `not_shared` (404) if that extension was never explicitly granted.
2. **There was no `GET /sharing` at all** - no way to list existing
   shares from either side (owner or invited user), so even with correct
   enforcement, nobody had a way to see or manage what they'd shared or
   been offered. Added, returning `{asOwner: [...], asInvited: [...]}`.

Wiring the frontend side of this surfaced a real bug: `ManageRecurring.jsx`
and `Settings.jsx` both fetched every account's recurring items with
`Promise.all`, which rejects entirely if ANY single request fails - so a
shared account with no recurring access (a legitimate, expected 404 now)
would have silently broken the recurring list for every OTHER account too.
Fixed with per-account `.catch(() => [])`.

## Custom Cognito Attribute: hasCompletedSetup

`lib/constructs/auth.ts` now defines a custom User Pool attribute,
`hasCompletedSetup`, used by the frontend to send a brand-new user to the
Getting Setup wizard automatically on their first sign-in, then never
again once they've been through it (or explicitly skipped it).

**Important if either environment has already been deployed**: Cognito
does not allow adding a new custom attribute to an existing User Pool -
only at creation time. If `FinanceApp-Beta` or `FinanceApp-Prod` have
already been through a real `cdk deploy`, this change will force CloudFormation
to replace the User Pool entirely, which means every existing user account
in that pool is gone and everyone has to sign up again. There's no
in-place migration path around this - it's a hard Cognito limitation, not
a mistake in this code. If real users already exist, this needs a
deliberate migration plan (e.g. export/re-invite users) rather than a
routine `cdk deploy`, and is worth confirming before running it.

## Beta vs. Prod

Same CDK code deployed twice via `bin/finance-app.ts`, parameterized by
`config/environments.ts`. Every resource is name-prefixed
(`finance-app-beta-*` / `finance-app-prod-*`) and tagged with
`Project`, `Environment`, and `ManagedBy` for cost tracking and console
filtering. Prod retains data on stack deletion (`RemovalPolicy.RETAIN`);
beta does not.

## Deploying

See `DEPLOY.md` for the full step-by-step beta deployment checklist -
bootstrap, deploy, verify, configure the frontend, and a first real
end-to-end pass covering everything built this project (MFA, sharing,
alerts, the recurring processor, account deletion).

## Commands

```bash
npm install
npx cdk bootstrap        # first time only, per AWS account/region
npm run diff:beta        # preview changes before deploying
npm run deploy:beta
npm run diff:prod
npm run deploy:prod
```

## What's implemented vs. stubbed

The infrastructure (tables, indexes, Cognito, API routes, IAM roles,
CloudFront routing) is fully wired and synthesizes cleanly. The Lambda
business logic reflects everything we designed — split-purchase entry,
budget threshold rules, cross-account category aggregation, CSV template
format — but several handlers have explicit `TODO`s where full logic still
needs to be written:

- Transaction edit/delete (with audit log writes)
- Account-to-account transfers
- Full projections calculation (income normalization, one-time credit handling)
- Budget start-date snapping to next paycheck (needs an income-schedule lookup)
- CSV import → transaction write (parsing/validation is done; the write-through isn't)
- Sharing invite accept/decline (invite lookup by composite key)
- Recurring transaction processing (no handler yet — likely a scheduled Lambda)

## Not yet in this scaffold

- Frontend app itself (React) — this only builds infrastructure to host it
- Getting Setup wizard / Walkthrough tour (frontend-only)
- Custom domain + ACM certificate wiring (commented placeholders in `frontend.ts`/`environments.ts`)
- SES sender identity verification (required before `ses:SendEmail` will actually deliver)
