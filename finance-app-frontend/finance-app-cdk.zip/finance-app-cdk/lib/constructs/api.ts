import { Construct } from "constructs";
import * as apigateway from "aws-cdk-lib/aws-apigateway";
import * as cognito from "aws-cdk-lib/aws-cognito";
import { EnvironmentConfig } from "../../config/environments";
import { Lambdas } from "./lambdas";

interface ApiProps {
  cfg: EnvironmentConfig;
  userPool: cognito.UserPool;
  lambdas: Lambdas;
}

export class Api extends Construct {
  public readonly restApi: apigateway.RestApi;

  constructor(scope: Construct, id: string, props: ApiProps) {
    super(scope, id);
    const { cfg, userPool, lambdas } = props;

    this.restApi = new apigateway.RestApi(this, "RestApi", {
      restApiName: `${cfg.resourcePrefix}-api`,
      deployOptions: { stageName: cfg.envName },
      defaultCorsPreflightOptions: {
        allowOrigins: apigateway.Cors.ALL_ORIGINS, // tighten to CloudFront domain once known
        allowMethods: apigateway.Cors.ALL_METHODS,
      },
    });

    const authorizer = new apigateway.CognitoUserPoolsAuthorizer(this, "Authorizer", {
      cognitoUserPools: [userPool],
    });

    const authOptions: apigateway.MethodOptions = {
      authorizer,
      authorizationType: apigateway.AuthorizationType.COGNITO,
    };

    // /accounts
    const accounts = this.restApi.root.addResource("accounts");
    accounts.addMethod("GET", new apigateway.LambdaIntegration(lambdas.accountsFn), authOptions);
    accounts.addMethod("POST", new apigateway.LambdaIntegration(lambdas.accountsFn), authOptions);
    const accountItem = accounts.addResource("{accountId}");
    accountItem.addMethod("PUT", new apigateway.LambdaIntegration(lambdas.accountsFn), authOptions);
    accountItem.addMethod("DELETE", new apigateway.LambdaIntegration(lambdas.accountsFn), authOptions);

    // /accounts/{accountId}/transactions
    const transactions = accountItem.addResource("transactions");
    transactions.addMethod("GET", new apigateway.LambdaIntegration(lambdas.transactionsFn), authOptions);
    transactions.addMethod("POST", new apigateway.LambdaIntegration(lambdas.transactionsFn), authOptions);
    const txnItem = transactions.addResource("{txnId}");
    txnItem.addMethod("PUT", new apigateway.LambdaIntegration(lambdas.transactionsFn), authOptions);
    txnItem.addMethod("DELETE", new apigateway.LambdaIntegration(lambdas.transactionsFn), authOptions);

    // /accounts/{accountId}/income (manual one-time credits: bonuses, gifts)
    accountItem
      .addResource("income")
      .addMethod("POST", new apigateway.LambdaIntegration(lambdas.transactionsFn), authOptions);

    // /accounts/{accountId}/recurring
    const recurring = accountItem.addResource("recurring");
    recurring.addMethod("GET", new apigateway.LambdaIntegration(lambdas.recurringFn), authOptions);
    recurring.addMethod("POST", new apigateway.LambdaIntegration(lambdas.recurringFn), authOptions);
    const recurringItem = recurring.addResource("{recurringId}");
    recurringItem.addMethod("PUT", new apigateway.LambdaIntegration(lambdas.recurringFn), authOptions);
    recurringItem.addMethod("DELETE", new apigateway.LambdaIntegration(lambdas.recurringFn), authOptions);
    recurringItem
      .addResource("occurrence")
      .addMethod("PUT", new apigateway.LambdaIntegration(lambdas.recurringFn), authOptions);

    // /transactions/transfer (between own accounts)
    const transfer = this.restApi.root
      .addResource("transactions")
      .addResource("transfer");
    transfer.addMethod("POST", new apigateway.LambdaIntegration(lambdas.transactionsFn), authOptions);

    // /budgets
    const budgets = this.restApi.root.addResource("budgets");
    budgets.addMethod("GET", new apigateway.LambdaIntegration(lambdas.budgetsFn), authOptions);
    budgets.addMethod("POST", new apigateway.LambdaIntegration(lambdas.budgetsFn), authOptions);
    // {sk} is "category#effectiveStartDate" - the frontend must
    // encodeURIComponent it, since it contains a literal "#"
    const budgetBySk = budgets.addResource("{sk}");
    budgetBySk.addMethod("DELETE", new apigateway.LambdaIntegration(lambdas.budgetsFn), authOptions);

    // /projections
    const projections = this.restApi.root.addResource("projections");
    projections.addMethod("GET", new apigateway.LambdaIntegration(lambdas.budgetsFn), authOptions);

    // /csv/export-template and /csv/import
    const csv = this.restApi.root.addResource("csv");
    csv.addResource("export-template").addMethod(
      "GET",
      new apigateway.LambdaIntegration(lambdas.csvFn),
      authOptions
    );
    csv.addResource("import").addMethod(
      "POST",
      new apigateway.LambdaIntegration(lambdas.csvFn),
      authOptions
    );

    // /csv/recurring/export-template and /csv/recurring/import
    const csvRecurring = csv.addResource("recurring");
    csvRecurring.addResource("export-template").addMethod(
      "GET",
      new apigateway.LambdaIntegration(lambdas.csvFn),
      authOptions
    );
    csvRecurring.addResource("import").addMethod(
      "POST",
      new apigateway.LambdaIntegration(lambdas.csvFn),
      authOptions
    );

    // /sharing
    const sharing = this.restApi.root.addResource("sharing");
    sharing.addMethod("GET", new apigateway.LambdaIntegration(lambdas.sharingFn), authOptions); // list, both sides
    sharing.addMethod("POST", new apigateway.LambdaIntegration(lambdas.sharingFn), authOptions); // invite
    const sharingAction = sharing.addResource("{invitationId}");
    sharingAction.addMethod("PUT", new apigateway.LambdaIntegration(lambdas.sharingFn), authOptions); // accept/decline
    sharingAction.addMethod("DELETE", new apigateway.LambdaIntegration(lambdas.sharingFn), authOptions); // revoke (owner)

    // /account/delete-me
    const account = this.restApi.root.addResource("account");
    account.addResource("delete-me").addMethod(
      "POST",
      new apigateway.LambdaIntegration(lambdas.deletionFn),
      authOptions
    );

    // /reconcile - bulk, across all accounts at once (no per-account clicking)
    const reconcile = this.restApi.root.addResource("reconcile");
    reconcile.addMethod("POST", new apigateway.LambdaIntegration(lambdas.reconcileFn), authOptions);

    // /payday/upcoming and /payday/submit
    const payday = this.restApi.root.addResource("payday");
    payday.addResource("upcoming").addMethod(
      "GET",
      new apigateway.LambdaIntegration(lambdas.paydayFn),
      authOptions
    );
    payday.addResource("submit").addMethod(
      "POST",
      new apigateway.LambdaIntegration(lambdas.paydayFn),
      authOptions
    );

    // /planned-expenses
    const plannedExpenses = this.restApi.root.addResource("planned-expenses");
    plannedExpenses.addMethod("GET", new apigateway.LambdaIntegration(lambdas.plannedExpensesFn), authOptions);
    plannedExpenses.addMethod("POST", new apigateway.LambdaIntegration(lambdas.plannedExpensesFn), authOptions);
    const plannedExpenseItem = plannedExpenses.addResource("{plannedExpenseId}");
    plannedExpenseItem.addMethod("PUT", new apigateway.LambdaIntegration(lambdas.plannedExpensesFn), authOptions);
    plannedExpenseItem.addMethod("DELETE", new apigateway.LambdaIntegration(lambdas.plannedExpensesFn), authOptions);

    // /external-bank-accounts - user-maintained list of real-world bank account labels
    const externalBankAccounts = this.restApi.root.addResource("external-bank-accounts");
    externalBankAccounts.addMethod(
      "GET",
      new apigateway.LambdaIntegration(lambdas.externalBankAccountsFn),
      authOptions
    );
    externalBankAccounts.addMethod(
      "POST",
      new apigateway.LambdaIntegration(lambdas.externalBankAccountsFn),
      authOptions
    );
    const externalBankAccountItem = externalBankAccounts.addResource("{externalBankAccountId}");
    externalBankAccountItem.addMethod(
      "PUT",
      new apigateway.LambdaIntegration(lambdas.externalBankAccountsFn),
      authOptions
    );
    externalBankAccountItem.addMethod(
      "DELETE",
      new apigateway.LambdaIntegration(lambdas.externalBankAccountsFn),
      authOptions
    );

    // /scenarios - saved what-if scenarios
    const scenarios = this.restApi.root.addResource("scenarios");
    scenarios.addMethod("GET", new apigateway.LambdaIntegration(lambdas.scenariosFn), authOptions);
    scenarios.addMethod("POST", new apigateway.LambdaIntegration(lambdas.scenariosFn), authOptions);

    // /scenarios/calculate - throwaway calculation, nothing saved
    scenarios.addResource("calculate").addMethod(
      "POST",
      new apigateway.LambdaIntegration(lambdas.scenariosFn),
      authOptions
    );

    // /scenarios/compare - up to 6 scenarios (saved and/or inline) side by side
    scenarios.addResource("compare").addMethod(
      "POST",
      new apigateway.LambdaIntegration(lambdas.scenariosFn),
      authOptions
    );

    const scenarioItem = scenarios.addResource("{scenarioId}");
    scenarioItem.addMethod("DELETE", new apigateway.LambdaIntegration(lambdas.scenariosFn), authOptions);
    scenarioItem.addResource("calculate").addMethod(
      "GET",
      new apigateway.LambdaIntegration(lambdas.scenariosFn),
      authOptions
    );

    // /peer-agreements - mutual consent to send/receive fund-movement notifications
    const peerAgreements = this.restApi.root.addResource("peer-agreements");
    peerAgreements.addMethod("POST", new apigateway.LambdaIntegration(lambdas.peerAgreementsFn), authOptions);
    peerAgreements.addMethod("GET", new apigateway.LambdaIntegration(lambdas.peerAgreementsFn), authOptions);

    const peerAgreementBySender = peerAgreements.addResource("{senderUserId}");
    peerAgreementBySender.addMethod("PUT", new apigateway.LambdaIntegration(lambdas.peerAgreementsFn), authOptions);

    // Separate resource path (same underlying data) so DELETE can accept
    // EITHER party's id in the URL without a routing conflict against the
    // PUT-by-senderUserId resource above.
    const peerAgreementByOther = peerAgreements.addResource("revoke").addResource("{otherUserId}");
    peerAgreementByOther.addMethod("DELETE", new apigateway.LambdaIntegration(lambdas.peerAgreementsFn), authOptions);

    // /peer-notifications - the fund-movement alerts themselves
    const peerNotifications = this.restApi.root.addResource("peer-notifications");
    peerNotifications.addMethod("POST", new apigateway.LambdaIntegration(lambdas.peerNotificationsFn), authOptions);
    peerNotifications.addMethod("GET", new apigateway.LambdaIntegration(lambdas.peerNotificationsFn), authOptions);
    peerNotifications
      .addResource("{notificationId}")
      .addMethod("DELETE", new apigateway.LambdaIntegration(lambdas.peerNotificationsFn), authOptions);

    // /preferences - user notification toggles
    const preferences = this.restApi.root.addResource("preferences");
    preferences.addMethod("GET", new apigateway.LambdaIntegration(lambdas.userPreferencesFn), authOptions);
    preferences.addMethod("PUT", new apigateway.LambdaIntegration(lambdas.userPreferencesFn), authOptions);
  }
}
